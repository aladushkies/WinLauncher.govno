package ru.winlauncher;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.graphics.Rect;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

/**
 * Accessibility hook used only for Samsung caption calibration and F11. Enable it from the
 * system Accessibility screen; it does not read or persist application text/content.
 */
public final class KeyService extends AccessibilityService {
    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.flags |= AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                    | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
                    | AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
            info.eventTypes = AccessibilityEvent.TYPE_WINDOWS_CHANGED
                    | AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
            info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
            setServiceInfo(info);
        }
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        LauncherPrefs prefs = new LauncherPrefs(this);
        if (prefs.isCaptionCalibrated()) return;
        try {
            for (AccessibilityWindowInfo window : getWindows()) {
                AccessibilityNodeInfo root = window.getRoot();
                if (root == null) continue;
                Rect windowBounds = new Rect();
                window.getBoundsInScreen(windowBounds);
                AccessibilityNodeInfo caption = findCaption(root);
                if (caption != null) {
                    Rect b = new Rect();
                    caption.getBoundsInScreen(b);
                    int height = b.height();
                    if (height >= 24 && height <= 96) {
                        prefs.setCaptionCalibration(height,
                                Math.max(0, b.left - windowBounds.left),
                                Math.max(0, windowBounds.right - b.right));
                    }
                    caption.recycle();
                    if (prefs.isCaptionCalibrated()) { root.recycle(); return; }
                }
                root.recycle();
            }
        } catch (Throwable ignored) { }
    }

    private AccessibilityNodeInfo findCaption(AccessibilityNodeInfo node) {
        if (node == null) return null;
        String id = node.getViewIdResourceName();
        if (id != null && (id.equals("com.samsung.android.framework.res:id/caption")
                || id.endsWith(":id/caption") || id.endsWith("/caption"))) return AccessibilityNodeInfo.obtain(node);
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            AccessibilityNodeInfo found = findCaption(child);
            if (child != null) child.recycle();
            if (found != null) return found;
        }
        return null;
    }

    private boolean escapeWasHandled;

    @Override protected boolean onKeyEvent(KeyEvent event) {
        WindowController controller=WindowController.active();
        if(controller!=null&&controller.handleSystemMenuKey(event))return true;
        int key=event.getKeyCode(),action=event.getAction(),meta=event.getMetaState();
        boolean alt=(meta&KeyEvent.META_ALT_ON)!=0,win=(meta&KeyEvent.META_META_ON)!=0;
        boolean ctrl=(meta&KeyEvent.META_CTRL_ON)!=0,shift=(meta&KeyEvent.META_SHIFT_ON)!=0;
        boolean ctrlShiftEsc=ctrl&&shift&&key==KeyEvent.KEYCODE_ESCAPE;
        if(ctrlShiftEsc){if(action==KeyEvent.ACTION_UP){android.content.Intent taskManager=new android.content.Intent(this,TaskManagerActivity.class);taskManager.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(taskManager);}return true;}

        if(key==KeyEvent.KEYCODE_ESCAPE){
            if(action==KeyEvent.ACTION_DOWN){
                escapeWasHandled=(SnapController.active()!=null&&SnapController.active().hasAssist())
                        ||TaskViewOverlay.isShowing()||ActionCenterOverlay.isShowing()
                        ||FullscreenEdgeManager.isMiniShowing()||ChromeManager.hasEscapeOverlay()
                        ||controller!=null&&controller.willHandleEscapeFullscreen();
                return escapeWasHandled;
            }
            if(action==KeyEvent.ACTION_UP){
                boolean handled=escapeWasHandled;escapeWasHandled=false;
                if(!handled)return false;
                if(SnapController.active()!=null&&SnapController.active().hasAssist()){SnapController.active().cancelAssist();return true;}
                if(TaskViewOverlay.dismissForEscape())return true;
                if(ActionCenterOverlay.dismissActiveForEscape())return true;
                if(FullscreenEdgeManager.dismissMiniForEscape())return true;
                if(ChromeManager.dismissOverlayForEscape())return true;
                return controller!=null&&controller.handleEscapeFullscreen();
            }
            return escapeWasHandled;
        }

        boolean f11=key==KeyEvent.KEYCODE_F11;
        boolean altSpace=alt&&key==KeyEvent.KEYCODE_SPACE;
        boolean altF11=alt&&f11;
        boolean altTab=alt&&key==KeyEvent.KEYCODE_TAB;
        boolean altF4=alt&&key==KeyEvent.KEYCODE_F4;
        boolean winCtrlDesktop=win&&ctrl&&(key==KeyEvent.KEYCODE_DPAD_LEFT||key==KeyEvent.KEYCODE_DPAD_RIGHT);
        boolean winArrow=win&&!ctrl&&(key==KeyEvent.KEYCODE_DPAD_LEFT||key==KeyEvent.KEYCODE_DPAD_RIGHT
                ||key==KeyEvent.KEYCODE_DPAD_UP||key==KeyEvent.KEYCODE_DPAD_DOWN);
        boolean winDigit=win&&key>=KeyEvent.KEYCODE_1&&key<=KeyEvent.KEYCODE_9;
        boolean handledShortcut=f11||altSpace||altF11||altTab||altF4||winArrow||winCtrlDesktop||winDigit
                ||win&&(key==KeyEvent.KEYCODE_D||key==KeyEvent.KEYCODE_A||key==KeyEvent.KEYCODE_N
                ||key==KeyEvent.KEYCODE_I||key==KeyEvent.KEYCODE_TAB||key==KeyEvent.KEYCODE_Z
                ||key==KeyEvent.KEYCODE_T||key==KeyEvent.KEYCODE_MOVE_HOME)
                ||ctrl&&key==KeyEvent.KEYCODE_D||key==KeyEvent.KEYCODE_SYSRQ;
        // S16: swallowing ACTION_DOWN is required to keep the platform from acting on the key, but
        // repeated DOWN events must not re-enter the handler (it used to queue one action per repeat).
        if(action==KeyEvent.ACTION_DOWN&&handledShortcut)return true;
        if(event.getRepeatCount()>0)return false;
        if(action!=KeyEvent.ACTION_UP)return false;
        if(f11&&controller!=null){if(altF11)controller.exitDockedPair();else controller.toggleFocusedFullscreen();return true;}
        if(altSpace){ChromeManager.showSystemMenuForFocused();return true;}
        if(altTab){if(DockService.taskView()!=null)DockService.taskView().show();return true;}
        if(altF4&&controller!=null){Win focused=controller.focusedWindow();if(focused!=null)controller.close(focused);return true;}
        if(key==KeyEvent.KEYCODE_SYSRQ&&controller!=null){
            controller.captureScreenshot(result->android.widget.Toast.makeText(this,
                    result.optBoolean("ok",false)?"Снимок сохранён: "+result.optString("path"):"Ошибка снимка: "+result.optString("error"),
                    android.widget.Toast.LENGTH_LONG).show());return true;
        }
        if(controller!=null&&winCtrlDesktop){controller.switchVirtualDesktop(controller.currentDesktopId()+(key==KeyEvent.KEYCODE_DPAD_RIGHT?1:-1));return true;}
        if(controller!=null&&winArrow){
            switch(key){case KeyEvent.KEYCODE_DPAD_LEFT:controller.keyboardSnap(true);break;case KeyEvent.KEYCODE_DPAD_RIGHT:controller.keyboardSnap(false);break;case KeyEvent.KEYCODE_DPAD_UP:controller.keyboardMaximizeUp();break;case KeyEvent.KEYCODE_DPAD_DOWN:controller.keyboardRestoreDown();break;}return true;
        }
        if(win&&winDigit&&controller!=null){controller.focusTaskbarIndex(key-KeyEvent.KEYCODE_1);return true;}
        if(ctrl&&key==KeyEvent.KEYCODE_D){if(controller!=null)controller.toggleShowDesktop();return true;}
        if(win){
            switch(key){
                case KeyEvent.KEYCODE_D:if(controller!=null)controller.toggleShowDesktop();return true;
                case KeyEvent.KEYCODE_A:case KeyEvent.KEYCODE_N:ActionCenterOverlay.showSingleton(this);return true;
                case KeyEvent.KEYCODE_I:startActivity(new android.content.Intent(this,LauncherSettingsActivity.class).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK));return true;
                case KeyEvent.KEYCODE_TAB:if(DockService.taskView()!=null)DockService.taskView().show();return true;
                case KeyEvent.KEYCODE_Z:ChromeManager.showLayoutsForFocused();return true;
                case KeyEvent.KEYCODE_T:if(controller!=null)controller.cycleTaskbarWindow();return true;
                case KeyEvent.KEYCODE_MOVE_HOME:if(controller!=null){Win focused=controller.focusedWindow();if(focused!=null)controller.aeroShake(focused);}return true;
            }
        }
        return false;
    }

    @Override public void onInterrupt() { }
}
