package ru.winlauncher;

import android.content.Context;

import android.content.Intent;

import android.graphics.Rect;

import android.graphics.RectF;

import android.os.Handler;

import android.os.Looper;

import android.view.KeyEvent;

import org.json.JSONArray;

import org.json.JSONObject;

import java.util.ArrayList;

import java.util.Collections;

import java.util.Comparator;

import java.util.LinkedHashMap;

import java.util.List;

import java.util.Map;

import java.util.Set;

import java.util.LinkedHashSet;

import ru.winlauncher.bridge.RootBridge;

/**
 * Small first-pass window state machine. All model mutations and listener callbacks are on the
 * main thread; Binder work is serialized by RootBridge. Freeform/fullscreen IDs are injected;
 * the Samsung docked split uses the current stack-3 profile and requires device validation.
 */

public final class WindowController {
    public static final int DOCKED_STACK_ID=3;
    private static volatile WindowController activeController;
    public static WindowController active() { return activeController; }

    public interface Listener { void onWindowsChanged(List<Win> windows); }
    public interface Result { void onResult(boolean ok, String message); }
    public interface ErrorListener { void onError(String message); }

    private final Context context;
    private final RootBridge root;
    private final LauncherPrefs prefs;
    private final WindowAnimator animator;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<Integer, Win> windows = new LinkedHashMap<>();
    private final Set<Integer> showDesktopRestoreIds = new LinkedHashSet<>();
    private final Set<Integer> pendingMinimizeIds = new LinkedHashSet<>();
    private final Set<Integer> pendingDesktopRestoreIds = new LinkedHashSet<>();
    private final Set<Integer> pendingDesktopPairExitIds = new LinkedHashSet<>();
    private boolean restoreShowDesktopWhenMinimized;
    private Win keyboardModeTarget;
    private boolean keyboardResizeMode;
    private final Rect keyboardModeStart=new Rect();
    private final List<Listener> listeners = new ArrayList<>();
    private ErrorListener errorListener;
    private SnapController snapController;
    private DockedPairManager dockedPair;
    private final int freeformStackId;
    private final int fullscreenStackId;
    private int screenWidth;
    private int screenHeight;
    private int taskbarHeight = 48;
    private boolean hideStatusBar = true;
    private boolean windowsButtonBehavior;
    private boolean statusConfigured;
    private boolean monitoring;
    private boolean initialized;
    private boolean restoringSnapGroup;
    private long generation;
    private long nextStatusAttempt;
    private String lastSignature;

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (!monitoring) return;
            refreshTasks(null);
            // S1: after a failure back off to one attempt every 8 s instead of hammering the
            // status-bar service on every tick.
            if (!statusConfigured && android.os.SystemClock.uptimeMillis() >= nextStatusAttempt) configureStatusBar();
            main.postDelayed(this, 750L);
        }
    };

    public WindowController(Context context, RootBridge root) {
        this(context, root, 2, 1);
    }

    public WindowController(Context context, RootBridge root, int freeformStackId, int fullscreenStackId) {
        this.context = context.getApplicationContext();
        this.root = root;
        this.prefs = new LauncherPrefs(this.context);
        this.animator = new WindowAnimator(this.context, root);
        this.hideStatusBar = prefs.hideStatusBar();
        this.windowsButtonBehavior = prefs.windowsButtonBehavior();
        this.freeformStackId = freeformStackId;
        this.fullscreenStackId = fullscreenStackId;
        activeController = this;
        updateDisplayGeometry();
        snapController = new SnapController(this.context, this);
        dockedPair = new DockedPairManager(this.context,this);
    }

    public void addListener(Listener listener) {
        if (!listeners.contains(listener)) listeners.add(listener);
        listener.onWindowsChanged(snapshot());
    }
    public void removeListener(Listener listener) { listeners.remove(listener); }
    public void setErrorListener(ErrorListener listener) { errorListener = listener; }

    public void setTaskbarHeight(int px) {
        int value=Math.max(0,px);if(taskbarHeight==value)return;taskbarHeight=value;
        Rect work=workArea();for(Win w:windows.values())if(w.state==Win.State.MAXIMIZED){requestBounds(w,work,0);}
        notifyListeners();
    }
    public boolean hideStatusBar() { return hideStatusBar; }
    public boolean windowsButtonBehavior() { return windowsButtonBehavior; }
    public void setWindowsButtonBehavior(boolean enabled) {
        windowsButtonBehavior=enabled;prefs.setWindowsButtonBehavior(enabled);notifyListeners();
    }
    public void setHideStatusBar(boolean hide) {
        hideStatusBar = hide;
        prefs.setHideStatusBar(hide);
        statusConfigured = false;
        if (monitoring) configureStatusBar();
        Rect work = workArea();
        for (Win w : windows.values()) if (w.state == Win.State.MAXIMIZED) {
            w.bounds.set(work);
            root.resize(w.taskId, work.left, work.top, work.right, work.bottom, 0, null);
        }
        notifyListeners();
    }

    private void configureStatusBar() {
        root.setStatusBarHidden(hideStatusBar, result -> {
            statusConfigured = result.optBoolean("ok", false);
            nextStatusAttempt = statusConfigured ? 0L
                    : android.os.SystemClock.uptimeMillis() + 8000L;
            if (!statusConfigured && errorListener != null)
                errorListener.onError(result.optString("error", "status-bar setup failed"));
        });
    }

    public void captureScreenshot(RootBridge.Callback callback){root.captureScreenshot(callback);}

    public void startMonitoring() {
        if (monitoring) return;
        monitoring = true;
        refreshTasks(null);
        configureStatusBar();
        main.removeCallbacks(poll);
        main.postDelayed(poll, 750L);
    }

    public void stopMonitoring() {
        monitoring = false;
        main.removeCallbacks(poll);
    }

    public void updateDisplayGeometry() {
        android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
        android.view.Display display = ((android.view.WindowManager)
                context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        display.getRealMetrics(dm); // task bounds and overlay coordinates use the whole display
        int oldWidth=screenWidth,oldHeight=screenHeight;boolean sizeChanged=oldWidth!=dm.widthPixels||oldHeight!=dm.heightPixels;
        boolean orientationChanged=oldWidth>0&&((oldHeight>oldWidth)!=(dm.heightPixels>dm.widthPixels));
        screenWidth = dm.widthPixels;
        screenHeight = dm.heightPixels;
        generation++;
        if(snapController!=null&&sizeChanged)snapController.displayChanged(orientationChanged);
        if(dockedPair!=null)dockedPair.onDisplayChanged();
    }

    public Rect workArea() {
        int top = hideStatusBar ? 0 : 24; // target device assumption: 24 px status-bar inset at 160 dpi
        return new Rect(0, top, screenWidth, Math.max(top, screenHeight - taskbarHeight));
    }

    private int statusBarHeight() {
        int id = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? context.getResources().getDimensionPixelSize(id) : 24;
    }
    private int dp(float value) { return (int)(value*context.getResources().getDisplayMetrics().density+0.5f); }

    public List<Win> snapshot() {
        ArrayList<Win> out = new ArrayList<>(windows.values());
        Collections.sort(out, Comparator.comparingInt(w -> w.z));
        return out;
    }

    public Win get(int taskId) { return windows.get(taskId); }
    public long geometryGeneration() { return generation; }
    public SnapController snapController() { return snapController; }
    public Rect displayBounds(){return new Rect(0,0,screenWidth,screenHeight);}
    public boolean hasDockedPair(){return dockedPair!=null&&dockedPair.isActive();}
    public boolean isDockedPairMember(Win w){return dockedPair!=null&&dockedPair.contains(w);}
    public void enterDockedPair(Win first,Win second){if(dockedPair!=null)dockedPair.enter(first,second);}
    public void exitDockedPair(){if(dockedPair!=null)dockedPair.exit(focusedWindow());}
    public void exitDockedPair(Win preferred){if(dockedPair!=null)dockedPair.exit(preferred);}
    public void moveDockedDivider(float ratio){if(dockedPair!=null)dockedPair.resizeTo(ratio);}
    public void releaseDockedPair(){if(dockedPair!=null)dockedPair.release();}
    public int currentDesktopId(){return prefs.currentVirtualDesktop();}
    public void focusTaskbarIndex(int index){
        ArrayList<Win> candidates=new ArrayList<>();
        for(Win w:snapshot())if(w.desktopId==currentDesktopId()&&(w.stackId==freeformStackId||w.state==Win.State.MINIMIZED))candidates.add(w);
        if(index<0||index>=candidates.size())return;Win target=candidates.get(index);
        if(target.state==Win.State.MINIMIZED)restore(target);else focus(target);
    }
    public void cycleTaskbarWindow(){
        ArrayList<Win> candidates=new ArrayList<>();
        for(Win w:snapshot())if(w.desktopId==currentDesktopId()&&(w.stackId==freeformStackId||w.state==Win.State.MINIMIZED))candidates.add(w);
        if(candidates.isEmpty())return;Win focused=focusedWindow();int i=candidates.indexOf(focused);Win next=candidates.get((i+1+candidates.size())%candidates.size());
        if(next.state==Win.State.MINIMIZED)restore(next);else focus(next);
    }
    public int virtualDesktopCount(){return prefs.virtualDesktopCount();}
    public int createVirtualDesktop(){
        int count=prefs.virtualDesktopCount();if(count>=4)return prefs.currentVirtualDesktop();
        prefs.setVirtualDesktopCount(count+1);switchVirtualDesktop(count);return count;
    }
    public void switchVirtualDesktop(int target){
        int count=prefs.virtualDesktopCount();target=Math.max(0,Math.min(count-1,target));int current=prefs.currentVirtualDesktop();if(target==current)return;
        java.util.Set<String> hidden=prefs.virtualDesktopHiddenTasks();java.util.Set<String> processedGroups=new java.util.LinkedHashSet<>();
        boolean leaveDockedPair=false;
        for(Win w:snapshot())if(w.desktopId==current&&w.state!=Win.State.MINIMIZED){
            if(w.snapGroupId!=null&&!processedGroups.add(w.snapGroupId))continue;
            if(dockedPair!=null&&dockedPair.contains(w)){
                Win first=dockedPair.first(),second=dockedPair.second();
                if(first!=null)hidden.add(String.valueOf(first.taskId));if(second!=null)hidden.add(String.valueOf(second.taskId));
                leaveDockedPair=true;continue;
            }
            for(Win member:snapController.groupMembers(w))if(member.state!=Win.State.MINIMIZED)hidden.add(String.valueOf(member.taskId));
            minimize(w);
        }
        prefs.setVirtualDesktopHiddenTasks(hidden);prefs.setCurrentVirtualDesktop(target);
        if(leaveDockedPair)scheduleDockedPairHideForInactiveDesktop();
        for(String id:new java.util.ArrayList<>(hidden)){
            Win w;try{w=windows.get(Integer.parseInt(id));}catch(NumberFormatException e){hidden.remove(id);continue;}
            if(w==null){hidden.remove(id);continue;}
            if(w.desktopId==target&&w.state==Win.State.MINIMIZED)restoreVirtualDesktopMember(w,hidden);
        }
        prefs.setVirtualDesktopHiddenTasks(hidden);notifyListeners();
    }
    private void restoreVirtualDesktopMember(Win w,java.util.Set<String> hidden){
        List<Win> members=snapController.groupMembers(w);
        boolean newlyPending=false;
        for(Win member:members){if(pendingDesktopRestoreIds.add(member.taskId))newlyPending=true;hidden.remove(String.valueOf(member.taskId));}
        if(!newlyPending)return;
        java.util.ArrayList<Integer> ids=new java.util.ArrayList<>();for(Win member:members)ids.add(member.taskId);
        main.postDelayed(()->pendingDesktopRestoreIds.removeAll(ids),2500L);
        restore(w);
    }
    private void reconcileVirtualDesktopVisibility(){
        int current=prefs.currentVirtualDesktop();java.util.Set<String> hidden=prefs.virtualDesktopHiddenTasks();
        java.util.Set<String> processed=new java.util.LinkedHashSet<>();boolean leaveDockedPair=false;
        for(Win w:snapshot()){
            String key=String.valueOf(w.taskId);
            if(w.state!=Win.State.MINIMIZED)pendingDesktopRestoreIds.remove(w.taskId);
            if(pendingDesktopPairExitIds.contains(w.taskId))continue;
            if(w.desktopId!=current&&w.state!=Win.State.MINIMIZED){
                if(dockedPair!=null&&dockedPair.contains(w)){
                    Win first=dockedPair.first(),second=dockedPair.second();
                    if(first!=null)hidden.add(String.valueOf(first.taskId));if(second!=null)hidden.add(String.valueOf(second.taskId));
                    leaveDockedPair=true;continue;
                }
                if(w.snapGroupId!=null&&!processed.add(w.snapGroupId))continue;
                for(Win member:snapController.groupMembers(w))if(member.state!=Win.State.MINIMIZED)hidden.add(String.valueOf(member.taskId));
                minimize(w);
            }else if(w.desktopId==current&&hidden.contains(key)&&w.state==Win.State.MINIMIZED){
                restoreVirtualDesktopMember(w,hidden);
            }
        }
        prefs.setVirtualDesktopHiddenTasks(hidden);
        if(leaveDockedPair)scheduleDockedPairHideForInactiveDesktop();
    }
    private void scheduleDockedPairHideForInactiveDesktop(){
        if(dockedPair==null||!dockedPair.isActive())return;
        Win first=dockedPair.first(),second=dockedPair.second();java.util.ArrayList<Win> members=new java.util.ArrayList<>();
        if(first!=null){members.add(first);pendingDesktopPairExitIds.add(first.taskId);}
        if(second!=null){members.add(second);pendingDesktopPairExitIds.add(second.taskId);}
        dockedPair.exit(null,()->{
            int current=prefs.currentVirtualDesktop();java.util.Set<String> hidden=prefs.virtualDesktopHiddenTasks();
            for(Win member:members){pendingDesktopPairExitIds.remove(member.taskId);if(member.desktopId!=current){hidden.add(String.valueOf(member.taskId));if(member.state!=Win.State.MINIMIZED)minimize(member);}else hidden.remove(String.valueOf(member.taskId));}
            prefs.setVirtualDesktopHiddenTasks(hidden);notifyListeners();
        });
    }
    public void moveWindowToDesktop(Win w,int desktop){
        if(w==null)return;desktop=Math.max(0,Math.min(prefs.virtualDesktopCount()-1,desktop));int old=w.desktopId;
        if(old==desktop)return;w.desktopId=desktop;prefs.setTaskDesktop(w.taskId,desktop);
        if(old==prefs.currentVirtualDesktop()&&w.state!=Win.State.MINIMIZED)minimize(w);
        if(desktop==prefs.currentVirtualDesktop()&&w.state==Win.State.MINIMIZED)restore(w);
        notifyListeners();
    }
    public void moveToDockedStack(Win w,Rect bounds,Result completion){
        Runnable resize=()->root.resize(w.taskId,bounds.left,bounds.top,bounds.right,bounds.bottom,0,result->{
            if(!result.optBoolean("ok",false)){report(result,null);if(completion!=null)completion.onResult(false,result.optString("error","resize failed"));return;}
            Rect actual=readConfirmedBounds(result);w.bounds.set(actual==null?bounds:actual);w.requestedBounds.set(w.bounds);w.stackId=DOCKED_STACK_ID;w.state=Win.State.FULLSCREEN;w.visible=true;notifyListeners();if(completion!=null)completion.onResult(true,"");
        });
        if(w.stackId!=DOCKED_STACK_ID)root.moveToStack(w.taskId,DOCKED_STACK_ID,true,result->{if(!result.optBoolean("ok",false)){report(result,null);if(completion!=null)completion.onResult(false,result.optString("error","stack move failed"));return;}resize.run();});else resize.run();
    }
    public void requestDockedBounds(Win w,Rect bounds){w.stackId=DOCKED_STACK_ID;w.state=Win.State.FULLSCREEN;w.visible=true;requestBounds(w,bounds,1);}
    public void moveFromDockedStack(Win w,Runnable after){
        Rect bounds=displayBounds();
        Runnable resize=()->root.resize(w.taskId,bounds.left,bounds.top,bounds.right,bounds.bottom,0,result->{
            if(!result.optBoolean("ok",false)){report(result,null);if(after!=null)after.run();return;}
            Rect actual=readConfirmedBounds(result);w.bounds.set(actual==null?bounds:actual);w.requestedBounds.set(w.bounds);w.stackId=fullscreenStackId;w.state=Win.State.FULLSCREEN;w.visible=true;notifyListeners();if(after!=null)after.run();
        });
        if(w.stackId!=fullscreenStackId)root.moveToStack(w.taskId,fullscreenStackId,true,result->{if(!result.optBoolean("ok",false)){report(result,null);if(after!=null)after.run();return;}resize.run();});else resize.run();
    }
    public void snapHalf(Win w, boolean left) { snapController.snapHalf(w, left); }
    public void applySnapBounds(Win w, Rect bounds, String groupId, int cell) {
        if (w.state == Win.State.NORMAL && w.hasUsableBounds()) w.normalBounds.set(w.bounds);
        w.snapGroupId=groupId; w.snapCell=cell;
        moveToStackThenResize(w, freeformStackId, true, clamp(bounds), Win.State.SNAPPED, null);
    }
    public void releaseActive() { if(activeController==this)activeController=null;if(snapController!=null)snapController.releaseActive();if(dockedPair!=null)dockedPair.release(); }
    public Win focusedWindow() {
        Win full=null,desktop=null;
        for (Win w : windows.values()) if (w.visible && w.state!=Win.State.MINIMIZED) {
            if((w.stackId==fullscreenStackId||w.stackId==DOCKED_STACK_ID)&&(full==null||w.z>full.z))full=w;
            else if(w.stackId==freeformStackId&&(desktop==null||w.z>desktop.z))desktop=w;
        }
        return full!=null?full:desktop;
    }
    public void toggleFocusedFullscreen() {
        Win top = focusedWindow();
        if (top != null) toggleFullscreen(top);
    }
    public boolean willHandleEscapeFullscreen(){Win w=focusedWindow();return prefs.escapeExitsFullscreen()&&w!=null&&w.state==Win.State.FULLSCREEN;}
    public boolean handleEscapeFullscreen(){
        if(!willHandleEscapeFullscreen())return false;
        Win w=focusedWindow();if(dockedPair!=null&&dockedPair.contains(w))dockedPair.exit(w,()->maximize(w));else maximize(w);
        return true;
    }
    public void keyboardSnap(boolean left) {
        Win w=focusedWindow(); if(w==null||w.stackId!=freeformStackId)return;
        if(w.state==Win.State.SNAPPED && w.snapGroupId!=null && w.snapCell>=0) {
            SnapController.Group g=snapController.group(w.snapGroupId);
            if(g!=null && g.layout==SnapController.Layout.TWO_HALF && w.snapCell==(left?0:1)) {
                snapController.snap(w,SnapController.Layout.FOUR_GRID,left?0:1,true); return;
            }
            if(g!=null && g.layout==SnapController.Layout.FOUR_GRID && w.snapCell==(left?0:1)) {
                snapController.snap(w,SnapController.Layout.FOUR_GRID,left?2:3,true); return;
            }
        }
        snapController.snapHalf(w,left);
    }
    public void keyboardMaximizeUp() {
        Win w=focusedWindow();if(w==null)return;
        if(w.state==Win.State.NORMAL||w.state==Win.State.SNAPPED)maximize(w);
        else if(w.state==Win.State.MAXIMIZED&&!windowsButtonBehavior)fullscreen(w);
    }
    public void keyboardRestoreDown() {
        Win w=focusedWindow();if(w==null)return;
        if(w.state==Win.State.FULLSCREEN)maximize(w);
        else if(w.state==Win.State.MAXIMIZED||w.state==Win.State.SNAPPED)restoreNormal(w);
        else if(w.state==Win.State.NORMAL)minimize(w);
    }

    public void refreshTasks(Result callback) {
        root.tasks(result -> {
            if (!result.optBoolean("ok", false)) {
                if (callback != null) callback.onResult(false, result.optString("error", "tasks failed"));
                return;
            }
            try {
                JSONArray tasks = result.getJSONArray("tasks");
                adoptTasks(tasks);
                if (callback != null) callback.onResult(true, "Задач: " + tasks.length());
            } catch (Exception e) {
                if (callback != null) callback.onResult(false, "Некорректный ответ tasks: " + e.getMessage());
            }
        });
    }

    private void adoptTasks(JSONArray tasks) throws Exception {
        Map<Integer, Boolean> seen = new LinkedHashMap<>();
        List<Win> newlyObserved=new ArrayList<>();
        String ownPackage = context.getPackageName();
        int activeFullscreenId=-1,activeFullscreenZ=Integer.MIN_VALUE;
        for(int i=0;i<tasks.length();i++){JSONObject row=tasks.getJSONObject(i);String pkg=componentPackage(row.optString("component",""));
            if(row.optInt("stack",-1)==fullscreenStackId&&row.optBoolean("visible",false)&&!pkg.equals(ownPackage)&&row.optInt("z",i)>activeFullscreenZ){activeFullscreenId=row.optInt("id",-1);activeFullscreenZ=row.optInt("z",i);}}
        for (int i = 0; i < tasks.length(); i++) {
            JSONObject row = tasks.getJSONObject(i);
            int id = row.getInt("id");
            int stack = row.optInt("stack", -1);
            String component = row.optString("component", "");
            String pkg = componentPackage(component);
            if (pkg.equals(ownPackage)) continue;
            Win w = windows.get(id);
            if (w == null) {
                // Keep fullscreen-stack history as selectable candidates for docked-stack pairs;
                // only the top stack-1 task is visible until a pair is explicitly formed.
                if(stack!=freeformStackId&&stack!=fullscreenStackId&&stack!=DOCKED_STACK_ID)continue;
                w = new Win(id);
                w.packageName = pkg;
                w.component = component;
                w.title = resolveTitle(pkg, component);
                w.stackId = stack;
                w.desktopId=prefs.taskDesktop(id,prefs.currentVirtualDesktop());
                w.visible = row.optBoolean("visible", false)&&(stack==freeformStackId||stack==DOCKED_STACK_ID||id==activeFullscreenId);
                w.z = row.optInt("z", i);
                readBounds(w.bounds, row.optJSONArray("bounds"));
                if(stack==fullscreenStackId||stack==DOCKED_STACK_ID)w.state=Win.State.FULLSCREEN;
                else if (sameRect(w.bounds, workArea())) w.state = Win.State.MAXIMIZED;
                else w.state = Win.State.NORMAL;
                if (w.state == Win.State.NORMAL) w.normalBounds.set(w.bounds);
                restorePersistedMinimizedState(w);
                windows.put(id, w);
                if(initialized && w.hasUsableBounds()&&w.state!=Win.State.MINIMIZED)newlyObserved.add(w);
            } else {
                w.packageName = pkg;
                w.component = component;
                w.title = resolveTitle(pkg, component);
                w.stackId = stack;
                w.visible = row.optBoolean("visible", false) && (stack!=fullscreenStackId || id==activeFullscreenId) && w.state!=Win.State.MINIMIZED;
                w.z = row.optInt("z", i);
                Rect actual = new Rect();
                readBounds(actual, row.optJSONArray("bounds"));
                if (actual.width() > 0 && actual.height() > 0) w.bounds.set(actual);
                if(stack==freeformStackId&&w.state!=Win.State.MINIMIZED){
                    if(sameRect(w.bounds,workArea())){
                        // Reconcile native/Samsung maximize actions as well as launcher actions.
                        // A snapped member maximized outside our own chrome must leave its group.
                        if(w.state==Win.State.SNAPPED&&w.snapGroupId!=null)snapController.detach(w);
                        w.state=Win.State.MAXIMIZED;
                    }else if(w.state==Win.State.FULLSCREEN||w.state==Win.State.MAXIMIZED){
                        w.state=Win.State.NORMAL;
                        w.normalBounds.set(w.bounds);
                    }
                }
                if ((stack == fullscreenStackId||stack==DOCKED_STACK_ID) && w.state != Win.State.MINIMIZED) w.state = Win.State.FULLSCREEN;
            }
            seen.put(id, true);
        }
        ArrayList<Integer> remove = new ArrayList<>();
        for (Integer id : windows.keySet()) if (!seen.containsKey(id)) remove.add(id);
        for (Integer id : remove) {
            pendingMinimizeIds.remove(id);showDesktopRestoreIds.remove(id);
            Win removedWindow=windows.get(id);
            if(removedWindow!=null){
                snapController.detach(removedWindow);
                if(dockedPair!=null&&dockedPair.contains(removedWindow)){Win other=dockedPair.first()==removedWindow?dockedPair.second():dockedPair.first();dockedPair.onTaskRemoved(removedWindow,other!=null&&!remove.contains(other.taskId));}
            }
            windows.remove(id);prefs.clearSavedWindow(id);prefs.clearTaskDesktop(id);
        }
        restoreShowDesktopWhenReady();
        if(dockedPair!=null&&!dockedPair.isActive()){
            ArrayList<Win> docked=new ArrayList<>();for(Win w:windows.values())if(w.stackId==DOCKED_STACK_ID)docked.add(w);
            if(docked.size()>=2){Collections.sort(docked,Comparator.comparingInt(w->w.z));dockedPair.adoptExisting(docked.get(0),docked.get(1));}
        }
        reconcileVirtualDesktopVisibility();
        // S4 (poll half: S9): one notify per real model change. The 750 ms poll used to rebuild
        // every chrome, grip, taskbar button, divider and Task View row even when nothing moved.
        String signature=stateSignature();
        boolean changed=!initialized||!signature.equals(lastSignature);
        lastSignature=signature;
        if(changed)notifyListeners();
        if(initialized)for(Win w:newlyObserved)animator.transition(w,new Rect(w.bounds),WindowAnimator.Kind.OPEN,()->{});
        initialized=true;
    }

    /** S4 helper: compact signature of everything the overlays render. */
    private String stateSignature(){
        StringBuilder b=new StringBuilder(windows.size()*48);
        for(Win w:snapshot())b.append(w.taskId).append(':').append(w.stackId).append(':').append(w.state.ordinal())
                .append(':').append(w.visible?'1':'0').append(':').append(w.z).append(':').append(w.desktopId)
                .append(':').append(w.snapCell).append(':').append(w.bounds.toShortString()).append(';');
        return b.toString();
    }

    private String resolveTitle(String pkg, String component) {
        try {
            CharSequence label = context.getPackageManager().getApplicationLabel(
                    context.getPackageManager().getApplicationInfo(pkg, 0));
            if (label != null) return label.toString();
        } catch (Exception ignored) { }
        if (component != null && component.contains("/")) return component.substring(component.indexOf('/') + 1);
        return pkg == null || pkg.length() == 0 ? "Окно" : pkg;
    }

    private static String componentPackage(String component) {
        if (component == null) return "";
        int slash = component.indexOf('/');
        return slash >= 0 ? component.substring(0, slash) : component;
    }

    private static void readBounds(Rect out, JSONArray a) {
        if (a == null || a.length() != 4) return;
        out.set(a.optInt(0), a.optInt(1), a.optInt(2), a.optInt(3));
    }

    private void restorePersistedMinimizedState(Win w){
        String saved=prefs.savedWindow(w.taskId);if(saved==null)return;
        String[] parts=saved.split("\\|",-1);if(parts.length<3||!w.packageName.equals(parts[0]))return;
        try{
            Win.State before=Win.State.valueOf(parts[1]);String[] xy=parts[2].split(",");if(xy.length!=4)return;
            Rect restoreBounds=new Rect(Integer.parseInt(xy[0]),Integer.parseInt(xy[1]),Integer.parseInt(xy[2]),Integer.parseInt(xy[3]));
            if(restoreBounds.width()>0&&restoreBounds.height()>0){w.normalBounds.set(restoreBounds);w.minimizeRestoreBounds.set(restoreBounds);}
            w.stateBeforeMinimize=before;w.state=Win.State.MINIMIZED;w.visible=false;
            if(parts.length>=6&&parts[3].length()>0&&parts[4].length()>0)try{
                SnapController.Layout layout=SnapController.Layout.valueOf(parts[4]);int cell=Integer.parseInt(parts[5]);RectF cellBounds=null;
                if(parts.length>=7&&parts[6].length()>0){String[] f=parts[6].split(",");if(f.length==4)cellBounds=new RectF(Float.parseFloat(f[0]),Float.parseFloat(f[1]),Float.parseFloat(f[2]),Float.parseFloat(f[3]));}
                snapController.restorePersistedMember(w,parts[3],layout,cell,cellBounds);
            }catch(RuntimeException ignored){}
            ensureMinimizedParked(w);
        }catch(RuntimeException ignored){}
    }
    private void ensureMinimizedParked(Win w){
        int original=w.stackId;
        root.moveToStack(w.taskId,fullscreenStackId,false,result->{
            if(result.optBoolean("ok",false)){w.stackId=fullscreenStackId;notifyListeners();return;}
            root.moveToStack(w.taskId,original,false,fallback->{
                if(fallback.optBoolean("ok",false)){w.stackId=original;notifyListeners();return;}
                try{Intent home=new Intent(Intent.ACTION_MAIN);home.addCategory(Intent.CATEGORY_HOME);home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);context.startActivity(home);}
                catch(RuntimeException ignored){}
            });
        });
    }

    private static boolean sameRect(Rect a, Rect b) {
        return Math.abs(a.left - b.left) <= 2 && Math.abs(a.top - b.top) <= 2
                && Math.abs(a.right - b.right) <= 2 && Math.abs(a.bottom - b.bottom) <= 2;
    }

    public void focus(Win w) {
        List<Win> members;
        if(dockedPair!=null&&dockedPair.contains(w)){
            members=new ArrayList<>();
            if(dockedPair.first()!=null)members.add(dockedPair.first());
            if(dockedPair.second()!=null)members.add(dockedPair.second());
        }else members=snapController.groupMembers(w);
        List<Win> raise=new ArrayList<>();
        for(Win member:members)if(member.visible&&member.state!=Win.State.MINIMIZED)raise.add(member);
        if(!raise.contains(w))raise.add(w);
        if(raise.size()>1){
            Collections.sort(raise,Comparator.comparingInt(member->member.z));
            raise.remove(w);raise.add(w);
        }
        int z=0;for(Win member:raise){member.z=Integer.MAX_VALUE-raise.size()+z++;member.visible=true;}
        for(Win member:raise)root.front(member.taskId,result->{if(!result.optBoolean("ok",false))report(result,null);});
        notifyListeners();if(w.snapGroupId!=null)snapController.refreshGroup(w.snapGroupId);
    }

    public void aeroShake(Win source){
        Set<String> retained=new LinkedHashSet<>();
        if(source.snapGroupId!=null)retained.add(source.snapGroupId);
        Set<String> visited=new LinkedHashSet<>();
        for(Win candidate:snapshot()){
            if(!candidate.visible||candidate.state==Win.State.MINIMIZED||candidate.state==Win.State.FULLSCREEN)continue;
            if(candidate==source||candidate.snapGroupId!=null&&retained.contains(candidate.snapGroupId))continue;
            if(candidate.snapGroupId!=null&&!visited.add(candidate.snapGroupId))continue;
            minimize(candidate);
        }
    }

    public void toggleShowDesktop(){
        if(!showDesktopRestoreIds.isEmpty()){
            for(Integer id:showDesktopRestoreIds)if(pendingMinimizeIds.contains(id)){
                // A second Win+D during the minimize transition queues restoration instead of
                // clearing the restore set before the asynchronous stack operation finishes.
                restoreShowDesktopWhenMinimized=true;return;
            }
            restoreShowDesktopNow();return;
        }
        restoreShowDesktopWhenMinimized=false;
        Set<String> groups=new LinkedHashSet<>();
        for(Win w:snapshot())if(w.stackId==freeformStackId&&w.visible&&w.state!=Win.State.MINIMIZED){
            if(w.snapGroupId!=null&&!groups.add(w.snapGroupId))continue;
            showDesktopRestoreIds.add(w.taskId);
            if(w.snapGroupId!=null){for(Win member:snapController.groupMembers(w))showDesktopRestoreIds.add(member.taskId);}
            minimize(w);
        }
    }

    private void restoreShowDesktopNow(){
        Set<Integer> restoreIds=new LinkedHashSet<>(showDesktopRestoreIds);showDesktopRestoreIds.clear();
        restoreShowDesktopWhenMinimized=false;Set<String> restoredGroups=new LinkedHashSet<>();
        for(Integer id:restoreIds){Win w=windows.get(id);if(w==null||w.state!=Win.State.MINIMIZED)continue;if(w.snapGroupId!=null&&!restoredGroups.add(w.snapGroupId))continue;restore(w);}
    }

    private void restoreShowDesktopWhenReady(){
        if(!restoreShowDesktopWhenMinimized)return;
        for(Integer id:showDesktopRestoreIds)if(pendingMinimizeIds.contains(id))return;
        restoreShowDesktopNow();
    }

    public void beginKeyboardMove(Win w){prepareKeyboardWindow(w);keyboardModeTarget=w;keyboardResizeMode=false;keyboardModeStart.set(w.bounds);focus(w);}
    public void beginKeyboardResize(Win w){prepareKeyboardWindow(w);keyboardModeTarget=w;keyboardResizeMode=true;keyboardModeStart.set(w.bounds);focus(w);}
    private void prepareKeyboardWindow(Win w){if(w.state==Win.State.SNAPPED){snapController.detach(w);w.state=Win.State.NORMAL;w.normalBounds.set(w.bounds);notifyListeners();}}
    public boolean handleSystemMenuKey(KeyEvent event){
        if(keyboardModeTarget==null)return false;
        int key=event.getKeyCode();
        if(event.getAction()!=KeyEvent.ACTION_UP)return key==KeyEvent.KEYCODE_ESCAPE||key==KeyEvent.KEYCODE_ENTER||key==KeyEvent.KEYCODE_NUMPAD_ENTER||key>=KeyEvent.KEYCODE_DPAD_UP&&key<=KeyEvent.KEYCODE_DPAD_RIGHT;
        Win w=keyboardModeTarget;
        if(key==KeyEvent.KEYCODE_ESCAPE){requestBounds(w,keyboardModeStart,0);keyboardModeTarget=null;return true;}
        if(key==KeyEvent.KEYCODE_ENTER||key==KeyEvent.KEYCODE_NUMPAD_ENTER){commitMove(w);keyboardModeTarget=null;return true;}
        int step=(event.getMetaState()&KeyEvent.META_SHIFT_ON)!=0?dp(32):dp(8);Rect next=new Rect(w.requestedBounds.width()>0?w.requestedBounds:w.bounds);
        if(keyboardResizeMode){
            if(key==KeyEvent.KEYCODE_DPAD_LEFT)next.right-=step;else if(key==KeyEvent.KEYCODE_DPAD_RIGHT)next.right+=step;
            else if(key==KeyEvent.KEYCODE_DPAD_UP)next.bottom-=step;else if(key==KeyEvent.KEYCODE_DPAD_DOWN)next.bottom+=step;else return false;
            if(next.width()<dp(240))next.right=next.left+dp(240);if(next.height()<dp(160))next.bottom=next.top+dp(160);
        }else{
            if(key==KeyEvent.KEYCODE_DPAD_LEFT)next.offset(-step,0);else if(key==KeyEvent.KEYCODE_DPAD_RIGHT)next.offset(step,0);
            else if(key==KeyEvent.KEYCODE_DPAD_UP)next.offset(0,-step);else if(key==KeyEvent.KEYCODE_DPAD_DOWN)next.offset(0,step);else return false;

        }

        requestBounds(w,clamp(next),1);return true;

    }

    public void maximize(Win w) {

        if(dockedPair!=null&&dockedPair.contains(w)){dockedPair.exit(w,()->maximize(w));return;}

        if (w.state == Win.State.NORMAL && w.hasUsableBounds()) w.normalBounds.set(w.bounds);

        if (w.state == Win.State.SNAPPED) snapController.detach(w);

        moveToStackThenResize(w, freeformStackId, true, workArea(), Win.State.MAXIMIZED, null);

    }

    public void fullscreen(Win w) {

        if(dockedPair!=null&&dockedPair.contains(w)){dockedPair.exit(w);return;}

        // S25: F11 from a floating window used to lose the floating rectangle, so MAX afterwards
        // produced a full-screen "restored" window.
        if (w.state == Win.State.NORMAL && w.hasUsableBounds()) w.normalBounds.set(w.bounds);

        if (w.state == Win.State.SNAPPED) snapController.detach(w);

        Rect target=new Rect(0,0,screenWidth,screenHeight);

        animator.transition(w,target,WindowAnimator.Kind.RESTORE,()->root.moveToStack(w.taskId,fullscreenStackId,true,moved->{

            if(!moved.optBoolean("ok",false)){report(moved,null);return;}

            w.stackId=fullscreenStackId;w.state=Win.State.FULLSCREEN;w.visible=true;

            root.resize(w.taskId,target.left,target.top,target.right,target.bottom,0,resized->{

                if(!resized.optBoolean("ok",false)){report(resized,null);notifyListeners();return;}

                Rect actual=readConfirmedBounds(resized);w.bounds.set(actual==null?target:actual);w.requestedBounds.set(w.bounds);notifyListeners();

            });

        }));

    }

    public void minimize(Win w) {

        if(dockedPair!=null&&dockedPair.contains(w)){dockedPair.exit(w,()->minimize(w));return;}

        List<Win> group=snapController.groupMembers(w);

        if(group.size()>1){for(Win member:new ArrayList<>(group))minimizeSingle(member);}

        else minimizeSingle(w);

    }

    private void minimizeSingle(Win w){

        if(w.state==Win.State.MINIMIZED||!pendingMinimizeIds.add(w.taskId))return;

        if(w.state==Win.State.NORMAL&&w.hasUsableBounds())w.normalBounds.set(w.bounds);

        final int originalStack=w.stackId;w.stateBeforeMinimize=w.state;

        Rect saved=w.stateBeforeMinimize==Win.State.SNAPPED&&w.hasUsableBounds()?new Rect(w.bounds):

                (w.normalBounds.width()>0&&w.normalBounds.height()>0?new Rect(w.normalBounds):new Rect(w.bounds));

        w.minimizeRestoreBounds.set(saved);

        SnapController.Group savedGroup=w.snapGroupId==null?null:snapController.group(w.snapGroupId);

        String layout=savedGroup==null?null:savedGroup.layout.name(),cellBounds=null;

        if(savedGroup!=null){RectF cell=savedGroup.cells.get(w.snapCell);if(cell!=null)cellBounds=cell.left+","+cell.top+","+cell.right+","+cell.bottom;}

        prefs.saveMinimizedState(w.taskId,w.packageName,saved.left,saved.top,saved.right,saved.bottom,w.stateBeforeMinimize.name(),w.snapGroupId,layout,w.snapCell,cellBounds);

        Rect target=new Rect(0,Math.max(0,screenHeight-taskbarHeight),dp(48),screenHeight);

        animator.transition(w,target,WindowAnimator.Kind.MINIMIZE,()->root.moveToStack(w.taskId,fullscreenStackId,false,result->{

            if(result.optBoolean("ok",false)){markMinimized(w,fullscreenStackId);return;}

            // Fallback 1: park behind peers in its current stack. Fallback 2: surface Home,

            // leaving the task restorable from the taskbar even on Samsung builds that reject stack 1.

            root.moveToStack(w.taskId,originalStack,false,fallback->{

                if(fallback.optBoolean("ok",false)){markMinimized(w,originalStack);return;}

                try{

                    Intent home=new Intent(Intent.ACTION_MAIN);home.addCategory(Intent.CATEGORY_HOME);home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                    context.startActivity(home);markMinimized(w,originalStack);

                }catch(RuntimeException e){prefs.clearSavedWindow(w.taskId);pendingMinimizeIds.remove(w.taskId);report(fallback,null);restoreShowDesktopWhenReady();}

            });

        }));

    }

    private void markMinimized(Win w,int parkedStack){

        pendingMinimizeIds.remove(w.taskId);

        w.state=Win.State.MINIMIZED;w.stackId=parkedStack;w.visible=false;if(w.snapGroupId!=null)snapController.refreshGroup(w.snapGroupId);notifyListeners();

        restoreShowDesktopWhenReady();

    }

    public void restore(Win w) {

        // S7: also pull in minimized siblings when the member itself is no longer MINIMIZED,
        // otherwise a SnapGroup could stay half-restored and half-parked behind the taskbar.
        if(!restoringSnapGroup){
            List<Win> group=snapController.groupMembers(w);
            boolean anyMinimized=false;
            for(Win member:group)if(member.state==Win.State.MINIMIZED)anyMinimized=true;
            if(group.size()>1&&anyMinimized){
                restoringSnapGroup=true;
                try{for(Win member:group)if(member.state==Win.State.MINIMIZED)restore(member);}
                finally{restoringSnapGroup=false;}
                if(w.state==Win.State.MINIMIZED)return;
            }
        }

        if (w.stateBeforeMinimize == Win.State.FULLSCREEN) {

            Rect target=new Rect(0,0,screenWidth,screenHeight);

            moveToStackThenResize(w,fullscreenStackId,true,target,Win.State.FULLSCREEN,()->{prefs.clearSavedWindow(w.taskId);w.minimizeRestoreBounds.setEmpty();focus(w);});

            return;

        }

        Rect target;Win.State restoreState=w.stateBeforeMinimize;

        if(restoreState==Win.State.MAXIMIZED)target=workArea();

        else if(restoreState==Win.State.SNAPPED){

            Rect snap=w.minimizeRestoreBounds.width()>0&&w.minimizeRestoreBounds.height()>0?new Rect(w.minimizeRestoreBounds):

                    (w.snapGroupId==null?null:snapController.boundsFor(w.snapGroupId,w.snapCell));

            target=snap!=null?snap:(w.normalBounds.width()>0?new Rect(w.normalBounds):fallbackNormalBounds());

        }else target=w.normalBounds.width()>0&&w.normalBounds.height()>0?new Rect(w.normalBounds):fallbackNormalBounds();

        final Win.State finalRestoreState=restoreState;

        target=clamp(target);

        moveToStackThenResize(w, freeformStackId, true, target, finalRestoreState, () -> {prefs.clearSavedWindow(w.taskId);w.minimizeRestoreBounds.setEmpty();focus(w);});

    }

    /** MAX follows the selected profile: Windows mode restores NORMAL; otherwise it cycles MAX/FULLSCREEN. */

    public void toggleMaximize(Win w) {

        if(w==null)return;

        switch (w.state) {

            case NORMAL:

            case SNAPPED: maximize(w); break;

            case MAXIMIZED: if(windowsButtonBehavior)restoreNormal(w);else fullscreen(w); break;

            case FULLSCREEN: maximize(w); break;

            case MINIMIZED: restore(w); break;

        }

    }

    public void toggleFullscreen(Win w) {

        if (w.state == Win.State.FULLSCREEN) maximize(w);

        else fullscreen(w);

    }

    public void toggleNormalMax(Win w) {

        if(w.state==Win.State.MAXIMIZED)restoreNormal(w);

        else if(w.state==Win.State.FULLSCREEN)maximize(w);

        else if(w.state==Win.State.MINIMIZED)restore(w);

        else maximize(w);

    }

    public void restoreNormal(Win w) {

        if(dockedPair!=null&&dockedPair.contains(w)){dockedPair.exit(w,()->restoreNormal(w));return;}

        if (w.state == Win.State.SNAPPED) snapController.detach(w);

        Rect target = w.normalBounds.width() > 0 && w.normalBounds.height() > 0

                ? new Rect(w.normalBounds) : fallbackNormalBounds();

        moveToStackThenResize(w, freeformStackId, true, clamp(target), Win.State.NORMAL, () -> focus(w));

    }

    /** Returns a maximized/snapped task to its saved window rectangle under the pointer. */

    public void restoreToNormal(Win w, Rect bounds) {

        if (w.state == Win.State.SNAPPED) snapController.detach(w);

        Rect target = clamp(bounds);

        // S6: the model must not claim NORMAL/freeform until moveToStack actually succeeded.
        // The old code mutated state and stackId up front; when the task was FULLSCREEN (stack 1)
        // with no stack-2 resize available, the window was reported as restored while still parked.
        w.requestedBounds.set(target);

        // The restored rectangle is remembered here; focus is left to the caller (a drag, a menu
        // action, or the snap cell-eviction path, which must not steal focus from the dragged window).
        moveToStackThenResize(w, freeformStackId, true, target, Win.State.NORMAL, () -> w.normalBounds.set(target));

    }

    public void requestMove(Win w, Rect bounds) {

        requestBounds(w, clamp(bounds), 1);

    }

    private void requestBounds(Win w, Rect target, int mode) {

        w.requestedBounds.set(target);

        final long seq = ++w.resizeSequence;

        root.resize(w.taskId, target.left, target.top, target.right, target.bottom, mode, result -> {

            if (seq != w.resizeSequence) return;

            if (!result.optBoolean("ok", false)) {

                if (!result.optString("error", "").contains("superseded")) report(result, null);

                return;

            }

            Rect actual = readConfirmedBounds(result);

            if (actual != null) {

                w.bounds.set(actual);

                w.requestedBounds.set(actual);

                if (w.state == Win.State.NORMAL) w.normalBounds.set(actual);

                notifyListeners();

            } else refreshTasks(null);

        });

    }

    public void commitMove(Win w) {

        Rect target = w.requestedBounds.width() > 0 && w.requestedBounds.height() > 0

                ? clamp(w.requestedBounds) : clamp(w.bounds);

        requestBounds(w, target, 0);

    }

    private Rect readConfirmedBounds(JSONObject response) {

        JSONArray a = response.optJSONArray("bounds");

        if (a == null || a.length() != 4) return null;

        return new Rect(a.optInt(0), a.optInt(1), a.optInt(2), a.optInt(3));

    }

    public void close(Win w) {

        if(dockedPair!=null&&dockedPair.contains(w)){dockedPair.exit(w,()->close(w));return;}

        snapController.detach(w);

        Rect b=w.hasUsableBounds()?new Rect(w.bounds):workArea();

        Rect target=new Rect(b);

        animator.transition(w,target,WindowAnimator.Kind.CLOSE,()->root.closeTask(w.taskId, result -> {

            if (!result.optBoolean("ok", false)) { report(result, null); return; }

            windows.remove(w.taskId);prefs.clearSavedWindow(w.taskId);

            notifyListeners();

        }));

    }

    private void moveToStackThenResize(Win w, int stack, boolean top, Rect target, Win.State targetState, Runnable after) {

        Runnable change=()->{

            Runnable resize = () -> root.resize(w.taskId, target.left, target.top, target.right, target.bottom, 0, result -> {

                if (!result.optBoolean("ok", false)) { report(result, null); return; }

                Rect actual = readConfirmedBounds(result);

                w.bounds.set(actual != null ? actual : target);

                w.requestedBounds.set(w.bounds);

                w.stackId = stack;

                w.state = targetState;

                w.visible = true;

                if(targetState==Win.State.NORMAL)w.normalBounds.set(w.bounds);

                notifyListeners();

                if (after != null) after.run();

            });

            if (w.stackId != stack) {

                root.moveToStack(w.taskId, stack, top, result -> {

                    if (!result.optBoolean("ok", false)) { report(result, null); return; }

                    resize.run();

                });

            } else resize.run();

        };

        animator.transition(w,target,targetState==Win.State.SNAPPED?WindowAnimator.Kind.SNAP:WindowAnimator.Kind.RESTORE,change);

    }

    private Rect fallbackNormalBounds() {

        Rect work = workArea();

        int width = Math.min(640, Math.max(240, work.width() * 2 / 3));

        int height = Math.min(480, Math.max(160, work.height() * 2 / 3));

        int left = Math.max(work.left, (work.width() - width) / 2);

        int top = Math.max(work.top, (work.height() - height) / 3);

        return new Rect(left, top, Math.min(work.right, left + width), Math.min(work.bottom, top + height));

    }

    private Rect clamp(Rect r) {

        Rect work = workArea();

        // S43: the old constants were raw pixels; on a 1.5x panel they shrank the tap-through
        // margin to ~32 px and the minimum window to 160x107 dp.
        int minW = Math.min(dp(240), work.width());

        int minH = Math.min(dp(160), work.height());

        int edge = dp(48);
        int title = dp(32);
        int width = Math.max(minW, Math.min(r.width(), work.width()));

        int height = Math.max(minH, Math.min(r.height(), work.height()));

        int left = Math.max(work.left - width + edge, Math.min(r.left, work.right - edge));

        int top = Math.max(work.top, Math.min(r.top, work.bottom - title));

        left = Math.min(left, work.right - edge);

        top = Math.min(top, work.bottom - minH);

        return new Rect(left, top, left + width, top + height);

    }

    /** S44: lets the settings screen push a theme/profile change without faking a task update. */
    public void refreshUi(){notifyListeners();}

    private void report(JSONObject result, Result callback) {

        String error = result.optString("error", "root operation failed");

        if (callback != null) callback.onResult(false, error);

        else if (errorListener != null) errorListener.onError(error);

    }

    private void notifyListeners() {

        List<Win> copy = snapshot();

        for (Listener listener : new ArrayList<>(listeners)) listener.onWindowsChanged(copy);

    }

}
