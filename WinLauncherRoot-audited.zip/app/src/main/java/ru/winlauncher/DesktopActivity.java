package ru.winlauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.appwidget.AppWidgetHost;
import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/** Opaque desktop shell with a low-cost geometric wallpaper and Android widgets hosted on the desktop. */
public final class DesktopActivity extends Activity {
    public static final int APP_WIDGET_HOST_ID=0x574c;
    private static final int REQUEST_WIDGET_BIND=7321,REQUEST_WIDGET_CONFIGURE=7322;
    private LauncherPrefs prefs;
    private BloomView wallpaper;
    private AppWidgetHost widgetHost;
    private AppWidgetManager widgetManager;
    private LinearLayout widgetContainer;
    private int pendingWidgetId=-1;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable slideshow= new Runnable(){@Override public void run(){if(prefs!=null&&prefs.wallpaperSlideshow()){prefs.setWallpaperIndex((prefs.wallpaperIndex()+1)%3);if(wallpaper!=null)wallpaper.invalidate();handler.postDelayed(this,60000L);}}};

    @Override protected void onCreate(Bundle state){super.onCreate(state);prefs=new LauncherPrefs(this);widgetManager=AppWidgetManager.getInstance(this);widgetHost=new AppWidgetHost(this,APP_WIDGET_HOST_ID);if(state!=null)pendingWidgetId=state.getInt("pending_widget_id",-1);build();if(prefs.wallpaperSlideshow())handler.postDelayed(slideshow,60000L);}
    @Override protected void onSaveInstanceState(Bundle out){out.putInt("pending_widget_id",pendingWidgetId);super.onSaveInstanceState(out);}
    @Override protected void onStart(){super.onStart();widgetHost.startListening();renderWidgets();}
    @Override protected void onStop(){widgetHost.stopListening();super.onStop();}

    private void build(){
        FrameLayout frame=new FrameLayout(this);wallpaper=new BloomView();frame.addView(wallpaper,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout screen=new LinearLayout(this);screen.setOrientation(LinearLayout.VERTICAL);screen.setPadding(dp(12),dp(12),dp(12),dp(8));
        TextView title=new TextView(this);title.setText("Рабочий стол");title.setTextColor(0xffffffff);title.setTextSize(20);screen.addView(title);
        LinearLayout icons=new LinearLayout(this);icons.setOrientation(LinearLayout.VERTICAL);
        addDesktopIcon(icons,"🌐","Edge Lite",()->startActivity(new Intent(this,EdgeLiteActivity.class)));
        addDesktopIcon(icons,"▦","Добавить виджет",this::showWidgetPicker);
        addDesktopIcon(icons,"⚙","Параметры",()->startActivity(new Intent(this,LauncherSettingsActivity.class)));
        Button apps=new Button(this);apps.setText("Все приложения");apps.setOnClickListener(v->showApps());screen.addView(apps,new LinearLayout.LayoutParams(dp(190),dp(44)));
        screen.addView(icons,new LinearLayout.LayoutParams(dp(200),-2));

        ScrollView widgetScroll=new ScrollView(this);widgetScroll.setFillViewport(false);widgetContainer=new LinearLayout(this);widgetContainer.setOrientation(LinearLayout.VERTICAL);widgetContainer.setPadding(0,dp(4),0,dp(4));widgetScroll.addView(widgetContainer);
        screen.addView(widgetScroll,new LinearLayout.LayoutParams(-1,0,1));
        TextView taskbar=new TextView(this);taskbar.setText("⊞     WinLauncher                         "+new java.text.SimpleDateFormat("HH:mm",java.util.Locale.getDefault()).format(new java.util.Date()));taskbar.setTextColor(0xff1a1a1a);taskbar.setGravity(Gravity.CENTER_VERTICAL);taskbar.setPadding(dp(16),0,dp(16),0);taskbar.setBackgroundColor(0xffe8e8e8);screen.addView(taskbar,new LinearLayout.LayoutParams(-1,dp(48)));
        frame.addView(screen,new FrameLayout.LayoutParams(-1,-1));setContentView(frame);
        wallpaper.setOnLongClickListener(v->{showBackgroundMenu();return true;});
        wallpaper.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_BUTTON_PRESS&&(e.getButtonState()&MotionEvent.BUTTON_SECONDARY)!=0){showBackgroundMenu();return true;}return false;});
    }
    private void addDesktopIcon(LinearLayout parent,String glyph,String label,Runnable action){
        LinearLayout tile=new LinearLayout(this);tile.setOrientation(LinearLayout.VERTICAL);tile.setGravity(Gravity.CENTER);tile.setPadding(dp(8),dp(8),dp(8),dp(8));tile.setBackgroundColor(0xff264678);
        TextView icon=new TextView(this);icon.setText(glyph);icon.setTextSize(28);icon.setTextColor(0xffffffff);icon.setGravity(Gravity.CENTER);tile.addView(icon,new LinearLayout.LayoutParams(dp(64),dp(48)));
        TextView text=new TextView(this);text.setText(label);text.setTextColor(0xffffffff);text.setTextSize(12);text.setGravity(Gravity.CENTER);tile.addView(text);
        tile.setOnClickListener(v->action.run());tile.setOnLongClickListener(v->{showBackgroundMenu();return true;});parent.addView(tile,new LinearLayout.LayoutParams(dp(96),dp(92)));
    }
    private void showBackgroundMenu(){
        String slideshowLabel=prefs.wallpaperSlideshow()?"Выключить смену обоев":"Включить смену обоев";
        new AlertDialog.Builder(this).setTitle("Рабочий стол").setItems(new String[]{"Следующие обои","Добавить виджет…",slideshowLabel,"Параметры"},(d,which)->{
            if(which==0){prefs.setWallpaperIndex((prefs.wallpaperIndex()+1)%3);wallpaper.invalidate();}
            else if(which==1)showWidgetPicker();
            else if(which==2){prefs.setWallpaperSlideshow(!prefs.wallpaperSlideshow());handler.removeCallbacks(slideshow);if(prefs.wallpaperSlideshow())handler.postDelayed(slideshow,60000L);}
            else startActivity(new Intent(this,LauncherSettingsActivity.class));
        }).show();
    }
    private void showApps(){
        PackageManager pm=getPackageManager();Intent query=new Intent(Intent.ACTION_MAIN,null);query.addCategory(Intent.CATEGORY_LAUNCHER);List<ResolveInfo> apps=pm.queryIntentActivities(query,0);Collections.sort(apps,(a,b)->String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));
        ScrollView scroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);scroll.addView(list);
        for(ResolveInfo app:apps){TextView item=new TextView(this);item.setText("  "+app.loadLabel(pm));item.setTextSize(16);item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(dp(8),0,dp(8),0);list.addView(item,new LinearLayout.LayoutParams(-1,dp(44)));item.setOnClickListener(v->{try{Intent launch=pm.getLaunchIntentForPackage(app.activityInfo.packageName);if(launch!=null)startActivity(launch);}catch(RuntimeException ignored){}});}
        new AlertDialog.Builder(this).setTitle("Приложения").setView(scroll).setNegativeButton("Закрыть",null).show();
    }

    private void showWidgetPicker(){
        List<AppWidgetProviderInfo> providers=widgetManager.getInstalledProviders();if(providers==null||providers.isEmpty()){Toast.makeText(this,"Установленные виджеты не найдены",Toast.LENGTH_SHORT).show();return;}
        ArrayList<AppWidgetProviderInfo> available=new ArrayList<>();ArrayList<String> labels=new ArrayList<>();
        for(AppWidgetProviderInfo info:providers){if(info.provider==null)continue;available.add(info);CharSequence label=info.loadLabel(getPackageManager());labels.add((label==null?info.provider.getClassName():label)+" · "+info.provider.getPackageName());}
        new AlertDialog.Builder(this).setTitle("Добавить виджет на рабочий стол").setItems(labels.toArray(new String[0]),(dialog,index)->bindWidget(available.get(index))).setNegativeButton("Отмена",null).show();
    }
    private void bindWidget(AppWidgetProviderInfo info){
        int id=widgetHost.allocateAppWidgetId();pendingWidgetId=id;Intent bind=new Intent(AppWidgetManager.ACTION_APPWIDGET_BIND);bind.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);bind.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER,info.provider);startActivityForResult(bind,REQUEST_WIDGET_BIND);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);int id=data==null?-1:data.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,-1);if(id<0)id=pendingWidgetId;
        if(requestCode==REQUEST_WIDGET_BIND){
            if(resultCode==RESULT_OK&&id>=0){AppWidgetProviderInfo info=widgetManager.getAppWidgetInfo(id);if(info!=null&&info.configure!=null){Intent config=new Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE);config.setComponent(info.configure);config.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);startActivityForResult(config,REQUEST_WIDGET_CONFIGURE);return;}saveWidget(id);}
            else if(id>=0)widgetHost.deleteAppWidgetId(id);
        }else if(requestCode==REQUEST_WIDGET_CONFIGURE){if(resultCode==RESULT_OK&&id>=0)saveWidget(id);else if(id>=0)widgetHost.deleteAppWidgetId(id);}
        pendingWidgetId=-1;
    }
    private void saveWidget(int id){Set<String> ids=prefs.appWidgetIds();ids.add(String.valueOf(id));prefs.setAppWidgetIds(ids);renderWidgets();}
    private void renderWidgets(){
        if(widgetContainer==null)return;widgetContainer.removeAllViews();
        // S32: a duplicated id in prefs used to create the same AppWidgetHostView twice, which
        // makes RemoteViews views share a single host and stop updating.
        java.util.Set<String> seenIds=new java.util.LinkedHashSet<>();
        for(String value:prefs.appWidgetIds())if(!seenIds.add(value))continue;
        for(String value:seenIds)try{
            int id=Integer.parseInt(value);AppWidgetProviderInfo info=widgetManager.getAppWidgetInfo(id);if(info==null)continue;
            AppWidgetHostView view=widgetHost.createView(this,id,info);view.setAppWidget(id,info);
            view.setOnLongClickListener(v->{new AlertDialog.Builder(this).setTitle("Виджет").setItems(new String[]{"Удалить виджет"},(d,which)->removeWidget(id)).setNegativeButton("Отмена",null).show();return true;});
            widgetContainer.addView(view,new LinearLayout.LayoutParams(-1,Math.max(dp(120),dp(info.minHeight))));
        }catch(NumberFormatException ignored){}
    }
    private void removeWidget(int id){widgetHost.deleteAppWidgetId(id);Set<String> ids=prefs.appWidgetIds();ids.remove(String.valueOf(id));prefs.setAppWidgetIds(ids);renderWidgets();}

    @Override protected void onDestroy(){handler.removeCallbacks(slideshow);super.onDestroy();}
    private int dp(float value){return(int)(value*getResources().getDisplayMetrics().density+.5f);}
    private final class BloomView extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        BloomView(){super(DesktopActivity.this);setBackgroundColor(0xff163365);}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);int index=prefs==null?0:prefs.wallpaperIndex()%3;int[] bases={0xff15345f,0xff182642,0xff23324a};canvas.drawColor(bases[index]);float cx=getWidth()*.67f,cy=getHeight()*.55f,r=Math.min(getWidth(),getHeight())*.30f;
            int[][] colors={{0xff187bd1,0xff14a5d7,0xff3158c9,0xff6843c2},{0xff1c9a9a,0xff31a76c,0xff3479bd,0xff6b59bb},{0xff5b78d0,0xffbf5c95,0xffe48b48,0xff387cb8}};
            for(int i=0;i<4;i++){paint.setColor(colors[index][i]);Path petal=new Path();float angle=(float)(i*Math.PI/2);float sx=cx+(float)Math.cos(angle)*r*.14f,sy=cy+(float)Math.sin(angle)*r*.14f;petal.moveTo(sx,sy);petal.cubicTo(cx+(float)Math.cos(angle-.85)*r*.15f,cy+(float)Math.sin(angle-.85)*r*.15f,cx+(float)Math.cos(angle-.6)*r*1.2f,cy+(float)Math.sin(angle-.6)*r*1.2f,cx+(float)Math.cos(angle)*r*1.25f,cy+(float)Math.sin(angle)*r*1.25f);petal.cubicTo(cx+(float)Math.cos(angle+.6)*r*1.2f,cy+(float)Math.sin(angle+.6)*r*1.2f,cx+(float)Math.cos(angle+.85)*r*.15f,cy+(float)Math.sin(angle+.85)*r*.15f,sx,sy);petal.close();canvas.drawPath(petal,paint);}
        }
    }
}
