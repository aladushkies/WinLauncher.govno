package ru.winlauncher;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Settings for title-button behavior, display profile, and app-specific fullscreen edges. */
public final class LauncherSettingsActivity extends Activity {
    private LauncherPrefs prefs;
    private LinearLayout appList;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = new LauncherPrefs(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(12), dp(16), dp(12));
        TextView title = new TextView(this);
        title.setText("Параметры WinLauncher"); title.setTextSize(22); title.setTextColor(0xff1a1a1a);
        page.addView(title);

        CheckBox windowsButton=new CheckBox(this);
        windowsButton.setText("Поведение как в Windows: MAX → NORMAL; F11/жест → FULLSCREEN");
        windowsButton.setChecked(prefs.windowsButtonBehavior());
        windowsButton.setOnCheckedChangeListener((b,checked)->prefs.setWindowsButtonBehavior(checked));
        page.addView(windowsButton);

        CheckBox escapeFullscreen=new CheckBox(this);
        escapeFullscreen.setText("Esc выходит из FULLSCREEN (по умолчанию выключено)");
        escapeFullscreen.setChecked(prefs.escapeExitsFullscreen());
        escapeFullscreen.setOnCheckedChangeListener((b,checked)->prefs.setEscapeExitsFullscreen(checked));
        page.addView(escapeFullscreen);

        CheckBox hide = new CheckBox(this);
        hide.setText("Скрывать системный статус-бар и блокировать раскрытие шторки");
        hide.setChecked(prefs.hideStatusBar());
        hide.setOnCheckedChangeListener((b, checked) -> prefs.setHideStatusBar(checked));
        page.addView(hide);

        CheckBox dark=new CheckBox(this);
        dark.setText("Тёмная тема заголовков, flyouts, Task View и краевых панелей");dark.setChecked(prefs.darkTheme());
        dark.setOnCheckedChangeListener((b,checked)->prefs.setDarkTheme(checked));page.addView(dark);

        CheckBox twoSwipe = new CheckBox(this);
        twoSwipe.setText("Fullscreen-зоны: требовать двойной свайп");
        twoSwipe.setChecked(prefs.doubleSwipeEdges());
        twoSwipe.setOnCheckedChangeListener((b, checked) -> prefs.setDoubleSwipeEdges(checked));
        page.addView(twoSwipe);

        CheckBox shake = new CheckBox(this);
        shake.setText("Встряхнуть окно — свернуть остальные окна (Aero Shake)");
        shake.setChecked(prefs.shakeToMinimize());
        shake.setOnCheckedChangeListener((b, checked) -> prefs.setShakeToMinimize(checked));
        page.addView(shake);

        TextView gapLabel = new TextView(this);
        gapLabel.setText("Зазор Snap: " + prefs.snapGapPx() + " px (0–8 px)");
        page.addView(gapLabel);
        SeekBar gap = new SeekBar(this);
        gap.setMax(8);
        gap.setProgress(prefs.snapGapPx());
        gap.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                prefs.setSnapGapPx(progress);
                gapLabel.setText("Зазор Snap: " + progress + " px (0–8 px)");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        page.addView(gap);

        TextView profileLabel = new TextView(this);
        profileLabel.setText("Профиль ввода (Авто: мышь → Mouse, иначе Touch)");
        profileLabel.setPadding(0, dp(12), 0, 0); page.addView(profileLabel);
        RadioGroup profiles = new RadioGroup(this);
        RadioButton auto = radio("Автоматически", "AUTO");
        RadioButton mouse = radio("Мышь", "MOUSE");
        RadioButton touch = radio("Сенсорный экран", "TOUCH");
        profiles.addView(auto); profiles.addView(mouse); profiles.addView(touch);
        String selected = prefs.inputProfile();
        profiles.check("MOUSE".equals(selected) ? mouse.getId() : "TOUCH".equals(selected) ? touch.getId() : auto.getId());
        profiles.setOnCheckedChangeListener((group, id) -> {
            if (id == auto.getId()) prefs.setAutoInputProfile();
            else prefs.setMouseProfile(id == mouse.getId());
        });
        page.addView(profiles);

        TextView edgeTitle = new TextView(this);
        edgeTitle.setText("Отключить краевые зоны для приложений");
        edgeTitle.setTextSize(18); edgeTitle.setPadding(0, dp(12), 0, dp(6)); page.addView(edgeTitle);
        appList = new LinearLayout(this); appList.setOrientation(LinearLayout.VERTICAL);
        ScrollView appScroll = new ScrollView(this); appScroll.addView(appList);
        page.addView(appScroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(page);
        populateApps();
    }

    private RadioButton radio(String label, String tag) {
        RadioButton b = new RadioButton(this); b.setText(label); b.setTag(tag); b.setId(View.generateViewId()); return b;
    }

    private void populateApps() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        Collections.sort(apps,(a,b)->String.valueOf(pm.getApplicationLabel(a)).compareToIgnoreCase(String.valueOf(pm.getApplicationLabel(b))));
        for (ApplicationInfo app : apps) {
            if (getPackageName().equals(app.packageName)) continue;
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(3), 0, dp(3));
            android.widget.ImageView icon = new android.widget.ImageView(this);
            try { icon.setImageDrawable(pm.getApplicationIcon(app)); } catch (Exception ignored) { }
            row.addView(icon, new LinearLayout.LayoutParams(dp(36), dp(36)));
            LinearLayout names = new LinearLayout(this); names.setOrientation(LinearLayout.VERTICAL);
            TextView label = new TextView(this); label.setText(pm.getApplicationLabel(app)); label.setSingleLine(true);
            TextView pkg = new TextView(this); pkg.setText(app.packageName); pkg.setTextSize(10); pkg.setTextColor(0xff666666);
            names.addView(label); names.addView(pkg);
            row.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
            Switch disabled = new Switch(this);
            disabled.setChecked(prefs.areEdgesDisabled(app.packageName));
            disabled.setOnCheckedChangeListener((button, checked) -> prefs.setEdgeDisabled(app.packageName, checked));
            row.addView(disabled);
            appList.addView(row, new LinearLayout.LayoutParams(-1, -2));
            View divider = new View(this); divider.setBackgroundColor(0xffe0e0e0);
            appList.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
        }
    }

    @Override protected void onStop(){
        super.onStop();
        WindowController controller=WindowController.active();
        if(controller!=null){
            // S44: status-bar and theme switches took effect only after an app restart.
            if(controller.hideStatusBar()!=prefs.hideStatusBar())controller.setHideStatusBar(prefs.hideStatusBar());
            controller.snapController().settingsChanged();
            controller.refreshTasks(null);
            controller.refreshUi();
        }
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
