#!/usr/bin/env python3
"""Static source-coherence checks. These do not compile, install, or execute the Android app."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
JAVA_ROOT = ROOT / "app/src/main/java/ru/winlauncher"

def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")

def java(name: str) -> str:
    return (JAVA_ROOT / f"{name}.java").read_text(encoding="utf-8")

def check(name: str, ok: bool) -> bool:
    print(f"{'PASS' if ok else 'FAIL'}  {name}")
    return ok

sources = {p: p.read_text(encoding="utf-8", errors="ignore") for p in JAVA_ROOT.rglob("*.java")}
all_java = "\n".join(sources.values())
APP_ROOT = ROOT / "app/src"
app_source_paths = [p for p in APP_ROOT.rglob("*") if p.is_file()]
app_source_text = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in app_source_paths)
xml_source_paths = [p for p in APP_ROOT.rglob("*.xml") if p.is_file()]
xml_source_text = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in xml_source_paths)
def source_has(pattern: str) -> bool:
    return re.search(pattern, app_source_text, re.IGNORECASE) is not None
font_suffixes = {".ttf", ".otf", ".woff", ".woff2"}
font_files = [p for p in (ROOT / "app").rglob("*") if p.is_file() and p.suffix.lower() in font_suffixes]
manifest = ET.fromstring(read("app/src/main/AndroidManifest.xml"))
manifest_text = read("app/src/main/AndroidManifest.xml")
checks = []

# 1. Font policy: system sans only; no branded font names or bundled font binaries.
font_name_pattern = re.compile("Seg" + "oe" + chr(92) + "s*" + "U" + "I", re.IGNORECASE)
repo_text_files = [p for p in ROOT.rglob("*") if p.is_file() and not any(part in {".git", ".gradle", "build", "out", "target", "node_modules"} for part in p.parts) and p.suffix.lower() not in {".zip", ".png", ".jpg", ".jpeg", ".webp", ".gif", ".apk", ".aab", ".ttf", ".otf", ".woff", ".woff2"}]
font_name_hits = [p for p in repo_text_files if font_name_pattern.search(p.read_text(encoding="utf-8", errors="ignore"))]
checks.append(check("system sans-serif is configured; no branded font name or font assets are present",
    'name="android:fontFamily"' in read("app/src/main/res/values/styles.xml") and "sans-serif" in read("app/src/main/res/values/styles.xml")
    and 'Typeface.create("sans-serif"' in java("ChromeManager")
    and not font_name_hits and not font_files))
checks.append(check("branded font name is absent from all project text files and asset paths",
    not font_name_hits and not any(font_name_pattern.search(str(p)) for p in ROOT.rglob("*"))))

# 2. Third-party app windows remain square.
chrome = java("ChromeManager")
checks.append(check("third-party window chrome remains square; no app-window corner clipping",
    "d.setCornerRadius(0)" in chrome and "квадратные opaque заголовки" in read("README.md")))

# 3. Independently report every forbidden visual effect and scan Java plus all XML resources.
forbidden_effect_patterns = {
    "PixelFormat.TRANSLUCENT": r"\bPixelFormat\s*\.\s*TRANSLUCENT\b",
    "Color.TRANSPARENT": r"\bColor\s*\.\s*TRANSPARENT\b",
    "setAlpha": r"\bsetAlpha\s*\(",
    "elevation": r"\bsetElevation\s*\(|\b(?:android:|app:)?elevation\s*=",
    "Mica": r"\bMica\b",
    "blur": r"\bblur\b",
    "RenderScript": r"\bRenderScript\b",
    "ScriptIntrinsicBlur": r"\bScriptIntrinsicBlur\b",
}
opaque_argb_hits, transparent_argb_hits, semi_transparent_argb_hits = [], [], []
def record_argb_alpha(alpha: int, location: tuple) -> None:
    if alpha == 255:
        opaque_argb_hits.append(location)
    elif alpha == 0:
        transparent_argb_hits.append(location)
    else:
        semi_transparent_argb_hits.append(location)
for source_path in app_source_paths:
    for line_no, line in enumerate(source_path.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
        for match in re.finditer(r"(?<![0-9a-fA-F])(?:0x|#)([0-9a-fA-F]{8})(?![0-9a-fA-F])", line):
            # RootServer's STATUS_BAR_DISABLE_* bit masks are integers, not ARGB colors.
            is_status_mask = source_path.name == "RootServer.java" and "int disable = hidden ?" in line
            if not is_status_mask:
                record_argb_alpha(int(match.group(1)[:2], 16), (str(source_path.relative_to(ROOT)), line_no, match.group(0)))
        argb = re.search(r"Color\s*\.\s*argb\s*\(\s*([^,]+)\s*,", line)
        if argb:
            expr = argb.group(1).strip().lower()
            try:
                record_argb_alpha(int(expr, 0), (str(source_path.relative_to(ROOT)), line_no, "Color.argb"))
            except ValueError:
                semi_transparent_argb_hits.append((str(source_path.relative_to(ROOT)), line_no, "dynamic Color.argb alpha"))
xml_alpha_attr_hits = [(str(p.relative_to(ROOT)), n, line.strip()) for p in xml_source_paths
    for n, line in enumerate(p.read_text(encoding="utf-8", errors="ignore").splitlines(), 1)
    if re.search(r"\bandroid:alpha\s*=", line, re.IGNORECASE)]
xml_transparent_color_hits, xml_semi_transparent_color_hits = [], []
for p in xml_source_paths:
    for n, line in enumerate(p.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
        for match in re.finditer(r"(?<![0-9a-fA-F])#([0-9a-fA-F]{8})(?![0-9a-fA-F])", line):
            alpha = int(match.group(1)[:2], 16)
            loc = (str(p.relative_to(ROOT)), n, match.group(0))
            if alpha == 0: xml_transparent_color_hits.append(loc)
            elif alpha != 255: xml_semi_transparent_color_hits.append(loc)
checks.append(check("combined visual-effects audit: Android source and XML are opaque and effect-free",
    not any(source_has(pattern) for pattern in forbidden_effect_patterns.values())
    and not transparent_argb_hits and not semi_transparent_argb_hits
    and not xml_alpha_attr_hits and not xml_transparent_color_hits and not xml_semi_transparent_color_hits
    and "PixelFormat.OPAQUE" in all_java))
for label, pattern in forbidden_effect_patterns.items():
    checks.append(check(f"forbidden {label} pattern absent from Android Java/XML/resources", not source_has(pattern)))
checks.append(check("opaque ARGB colors are recognized as alpha FF; opaque overlay format is used",
    bool(opaque_argb_hits) and "PixelFormat.OPAQUE" in all_java
    and not transparent_argb_hits and not semi_transparent_argb_hits))
checks.append(check("transparent ARGB values (alpha 00) are absent from app sources", not transparent_argb_hits))
checks.append(check("semi-transparent ARGB values (alpha 01–FE) are absent from app sources", not semi_transparent_argb_hits))
checks.append(check("XML resources contain no android:alpha attributes", not xml_alpha_attr_hits))
checks.append(check("XML color resources contain no transparent or semi-transparent alpha bytes",
    not xml_transparent_color_hits and not xml_semi_transparent_color_hits))

# 4. Window transitions never capture task imagery; standalone PrtSc is a separate file-based feature.
animator = java("WindowAnimator")
bridge = read("app/src/main/java/ru/winlauncher/bridge/RootBridge.java")
server = read("app/src/main/java/ru/winlauncher/root/RootServer.java")
keys_for_capture = java("KeyService")
window_for_capture = java("WindowController")
window_image_patterns = [r"getTaskThumbnail", r"SurfaceControl\s*\.\s*screenshot", r"BitmapFactory",
                        r"PixelCopy", r"getDrawingCache", r"drawToBitmap"]
checks.append(check("window animation code does not capture or animate window snapshots",
    not any(re.search(pattern, animator, re.IGNORECASE) for pattern in window_image_patterns)
    and not re.search(r"captureScreenshot|screencap|snapshot|thumbnail", animator, re.IGNORECASE)
    and "changeRealTask.run()" in animator and "AlphaAnimation" not in animator
    and "ObjectAnimator" not in animator))
task_image_api_patterns = window_image_patterns + [r"\bthumbnail\s*\("]
task_image_api_hits = [(p.name, pattern) for p, text in sources.items()
    if p.name != "SnapController.java" for pattern in task_image_api_patterns
    if re.search(pattern, text, re.IGNORECASE)]
checks.append(check("task-image thumbnail APIs, if used, are confined to Snap Assist; RootBridge carries no bitmap",
    not task_image_api_hits and "Base64" not in bridge and "Bitmap" not in bridge))
checks.append(check("PrtSc saves PNG via RootServer and returns only a path over RootBridge",
    "KEYCODE_SYSRQ" in keys_for_capture and "captureScreenshot" in keys_for_capture and "captureScreenshot" in window_for_capture
    and "captureScreenshot" in bridge and 'send("capture"' in bridge
    and 'case "capture"' in server and "/system/bin/screencap" in server
    and "/sdcard/Pictures/WinLauncher" in server and '"path",image.getAbsolutePath()' in server
    and "Bitmap" not in bridge and "Base64" not in bridge
    and "R-03" in read("TEST_PLAN.md")))
checks.append(check("README distinguishes PrtSc file capture from forbidden animation snapshots",
    "PrtSc сохраняет" in read("README.md") and "bitmap/Base64 не пересылаются" in read("README.md")
    and "снимки для анимаций запрещены" in read("README.md")
    and "только в Snap Assist" in read("README.md")
    and "(R-03)" in read("DEVICE_CHECKLIST.md") and "RootServer writes a PNG" in read("TEST_PLAN.md")))

# 5. Six snap layouts and assist use app icons, not captured window content.
snap = java("SnapController")
checks.append(check("six Snap Layouts, Snap Assist icons and optional thumbnails stay in the assist component",
    all(x in snap for x in ["TWO_HALF", "LEFT_66", "RIGHT_66", "THREE_MAIN", "THREE_COLUMNS", "FOUR_GRID", "class Assist", "getApplicationIcon", "dismissAssist()", "KEYCODE_ESCAPE", "ACTION_OUTSIDE"])
    and "public void updatePreview(Win w,float x,float y) { }" in snap))

# 6–8. Window core, SnapGroup, fullscreen edge zones, and docked pair.
window = java("WindowController")
pair = java("DockedPairManager")
edge = java("FullscreenEdgeManager")
taskview = java("TaskViewOverlay")
checks.append(check("window core has persistent minimize/restore state and grouped operations",
    all(x in window for x in ["minimizeSingle(", "restorePersistedMinimizedState", "aeroShake(", "toggleShowDesktop()", "snapController.groupMembers(w)"])
    and "clearSavedSnapGroup" in java("LauncherPrefs")))
checks.append(check("SnapGroup membership, group operations, divider and occupied-cell swap are present",
    all(x in snap for x in ["Map<Integer, Integer> tasks", "groupMembers(", "minimizeGroup(", "detachFromGroup(", "finishDividerDrag()", "group.tasks.put(swap,other.taskId)"])))
checks.append(check("fullscreen edge zones support per-app exclusions, double swipe and all panels",
    all(x in edge for x in ["enum Side { TOP,BOTTOM,LEFT,RIGHT }", "areEdgesDisabled(", "doubleSwipeEdges()", "showMini(active)", "taskView.show()", "actionCenter.show()", "showTemporary()"])))
checks.append(check("docked pair uses stack 3, constrained divider ratio and exit routes",
    "DOCKED_STACK_ID=3" in window and "root.moveToStack(w.taskId,DOCKED_STACK_ID,true" in window
    and "ratio=.5f" in pair and "clampRatio(" in pair and "moveFromDockedStack" in pair
    and "controller.enterDockedPair" in taskview and "exitDockedPair" in taskview))

# 9. Virtual desktops persisted and wired to taskbar / Task View.
prefs = java("LauncherPrefs")
taskbar = java("TaskbarOverlay")
checks.append(check("1–4 virtual desktops persist task assignment and filter the taskbar",
    all(x in prefs for x in ["virtualDesktopCount()", "taskDesktop(", "setTaskDesktop(", "current_virtual_desktop"])
    and "switchVirtualDesktop(" in window and "moveWindowToDesktop(" in window
    and "w.desktopId==controller.currentDesktopId()" in taskbar
    and all(x in taskview for x in ["createVirtualDesktop()", "switchVirtualDesktop(", "chooseDesktop(w)"])))

# 10. Requested keyboard mappings and documented Android restrictions.
keys = java("KeyService")
checks.append(check("implemented global shortcuts are wired and Win+L/system-reserved limits are documented",
    all(x in keys for x in ["KEYCODE_F11", "KEYCODE_SPACE", "KEYCODE_F4", "KEYCODE_TAB", "KEYCODE_Z", "KEYCODE_T", "KEYCODE_MOVE_HOME", "KEYCODE_DPAD_LEFT", "KEYCODE_DPAD_RIGHT", "KEYCODE_DPAD_UP", "KEYCODE_DPAD_DOWN", "META_META_ON", "KEYCODE_SYSRQ", "captureScreenshot"])
    and all(x in read("README.md") for x in ["Win+L", "Ctrl+Shift+Esc", "USES_POLICY_FORCE_LOCK", "android.permission.DEVICE_POWER", "Alt+Tab"])
    and "TaskManagerActivity.class" in keys and "K-20" in read("TEST_PLAN.md")))

# 11. Action Center: Android notification listener and root-backed control operations.
action = java("ActionCenterOverlay")
notification = java("LauncherNotificationListener")
server = read("app/src/main/java/ru/winlauncher/root/RootServer.java")
checks.append(check("Action Center can display real notifications and query/request root radio actions",
    "BIND_NOTIFICATION_LISTENER_SERVICE" in manifest_text and "getActiveNotifications()" in notification
    and all(x in notification for x in ["onNotificationPosted", "contentIntent", "EXTRA_TITLE"])
    and all(x in action for x in ["LauncherNotificationListener.snapshot()", "deviceState(action", "deviceAction(action", "ACTION_NOTIFICATION_LISTENER_SETTINGS"])
    and all(x in server for x in ["device_state", "mobile_data", "bluetooth"])))

# 12. Edge Lite browser and download integration.
browser = java("EdgeLiteActivity")
checks.append(check("Edge Lite has WebView tabs, DDG omnibox/history, drag reorder and DownloadManager",
    all(x in browser for x in ["WebView", "duckduckgo.com", "browserHistory()", "addBrowserHistory", "startDragAndDrop", "DownloadManager", "DIRECTORY_DOWNLOADS"])
    and "ru.winlauncher.EdgeLiteActivity" in manifest_text and "android.permission.INTERNET" in manifest_text))

# 13–14. AppWidgetHost must be mounted in DesktopActivity, not a separate screen.
desktop = java("DesktopActivity")
checks.append(check("AppWidgetHost bind/configure/persistence is integrated into DesktopActivity",
    all(x in desktop for x in ["AppWidgetHost", "ACTION_APPWIDGET_BIND", "ACTION_APPWIDGET_CONFIGURE", "appWidgetIds()", "deleteAppWidgetId", "renderWidgets()", "showWidgetPicker()"])
    and "ru.winlauncher.DesktopActivity" in manifest_text and "WidgetHostActivity" not in manifest_text))
checks.append(check("Desktop Home, opaque Bloom-inspired drawing, context menu and slideshow are wired",
    "android.intent.category.HOME" in manifest_text and "drawPath" in desktop
    and all(x in desktop for x in ["wallpaperSlideshow()", "setWallpaperIndex", "showBackgroundMenu", "EdgeLiteActivity", "AppWidgetHostView"])))

# 15. Ctrl+Shift+Esc opens a close-capable task list, not Task View.
task_manager = java("TaskManagerActivity")
ctrl_escape_branch = java("KeyService").split("if(ctrlShiftEsc)", 1)[1].split("if(key==KeyEvent.KEYCODE_ESCAPE)", 1)[0]
checks.append(check("Ctrl+Shift+Esc launches simple Task Manager with task rows, close and restore",
    "TaskManagerActivity.class" in ctrl_escape_branch and "taskView" not in ctrl_escape_branch
    and "ru.winlauncher.TaskManagerActivity" in manifest_text
    and all(x in task_manager for x in ["onWindowsChanged", "controller.close(win)", "controller.restore(win)", "Диспетчер задач"])))

# 15. Documentation coverage and build/runtime honesty.
readme = read("README.md")
testplan = read("TEST_PLAN.md")
device = read("DEVICE_CHECKLIST.md")
checks.append(check("README links a comprehensive test plan and does not claim build/device success",
    "PLAN.md" in readme and "TEST_PLAN.md" in readme and "APK не собран" in readme and "не проверены" in readme
    and "not prove" not in readme.lower()))
checks.append(check("test plan covers build, Stage 0/E-1…E-10 and requested subsystems with Pass/Fail fields",
    all(x in testplan for x in ["B-01", "T0", "E-1", "E-10", "getTaskThumbnail", "injectInputEvent", "resizeDockedStack", "K-01", "K-20", "☐ Pass ☐ Fail", "Samsung", "P-05"])
    and all(x in testplan for x in ["Virtual desktops", "Action Center", "Edge Lite", "AppWidgetHostView", "TaskManagerActivity", "rotation", "gestures"])))
checks.append(check("PLAN.md preserves exact E-1…E-10 hypotheses and Stage 1–4/Stage 5 decision",
    all(x in read("PLAN.md") for x in ["E‑1…E‑10", "am stack movetask taskId 2 true", "3 px", "resizeMode 0/1", "StackInfo", "SurfaceControl.screenshot", "/dev/input", "IStatusBarService.disable", "resizeDockedStack", "Этап 1", "Этап 2", "Этап 3", "Этап 4", "Этап 5"])))
checks.append(check("device checklist covers the ten hypotheses without claiming snapshot visuals",
    "fade" not in device.lower()
    and all(x in device for x in ["TEST_PLAN.md", "E-1…E-10", "getTaskThumbnail", "injectInputEvent", "resizeDockedStack", "stack IDs", "Wi‑Fi", "USES_POLICY_FORCE_LOCK", "AppWidgetHostView", "Ctrl+Shift+Esc"])))

# 16. GitHub hygiene.
gitignore = read(".gitignore")
checks.append(check("GitHub hygiene ignores local SDK/Gradle/build/signing artifacts",
    all(x in gitignore for x in ["local.properties", ".gradle/", "build/", "*.apk", "*.aab", "*.keystore", "*.jks"])))

# 17. Cheap lexical balance check for accidental editing damage (not a Java parser/compiler).
def balanced(text: str) -> bool:
    stack=[]; i=0; state="code"; pairs={')':'(',']':'[','}':'{'}
    while i<len(text):
        c=text[i]; n=text[i+1] if i+1<len(text) else ""
        if state=="line":
            if c=='\n': state="code"
        elif state=="block":
            if c=='*' and n=='/': state="code"; i+=1
        elif state in ("string", "char"):
            if c=='\\': i+=1
            elif (state=="string" and c=='"') or (state=="char" and c=="'"): state="code"
        elif c=='/' and n=='/': state="line"; i+=1
        elif c=='/' and n=='*': state="block"; i+=1
        elif c=='"': state="string"
        elif c=="'": state="char"
        elif c in "([{": stack.append(c)
        elif c in ")]}":
            if not stack or stack.pop()!=pairs[c]: return False
        i+=1
    return not stack and state not in ("block", "string", "char")
xml_ok=True
try:
    for p in (ROOT / "app/src/main").rglob("*.xml"): ET.parse(p)
except ET.ParseError:
    xml_ok=False
checks.append(check("Java delimiter balance and Android XML well-formedness (not compilation)",
    all(balanced(s) for s in sources.values()) and xml_ok))

# 18. Field-initializer hygiene. Three of the delivery bugs were exactly this class:
#     (b) a duplicated `lastWindows` declaration, (c)/(d) a lambda-field initializer reading a final
#     field the constructor assigns later. A duplicate or a direct forward read is a Java compile
#     error; a lambda read of a constructor-assigned final is a definite-assignment error.
def brace_depths(text: str):
    """Brace depth per character, ignoring comments, strings and chars."""
    depth, out, i, state = 0, [], 0, "code"
    while i < len(text):
        c, n = text[i], text[i + 1] if i + 1 < len(text) else ""
        if state == "code":
            if c == "/" and n == "/":
                state = "line"
            elif c == "/" and n == "*":
                state = "block"
            elif c == '"':
                state = "string"
            elif c == "'":
                state = "char"
            elif c == "{":
                depth += 1
            elif c == "}":
                depth = max(0, depth - 1)
        elif state == "line" and c == "\n":
            state = "code"
        elif state == "block" and c == "*" and n == "/":
            state, i = "code", i + 1
        elif state in ("string", "char"):
            if c == "\\":
                i += 1
            elif (state == "string" and c == '"') or (state == "char" and c == "'"):
                state = "code"
        out.append(depth)
        i += 1
    return out

field_forward_hits, duplicate_field_hits = [], []
for path, text in sources.items():
    body = re.sub(r'//[^\n]*|/\*.*?\*/', '', text, flags=re.S)
    depths = brace_depths(body)
    final_fields, declared_order = set(), {}
    for match in re.finditer(r'(?:^|\n)[ \t]*((?:public|private|protected|static|final|volatile|transient)[^\n;={}()]*?)[ \t](\w+)[ \t]*(?:=|;)', body):
        if depths[match.start()] != 1:
            continue
        modifiers, name = match.group(1), match.group(2)
        if 'final' in modifiers.split():
            final_fields.add(name)
        if name in declared_order:
            duplicate_field_hits.append((path.name, name))
        declared_order.setdefault(name, len(declared_order) + 1)
    assigned_in_constructor = set()
    for ctor in re.finditer(r'\b(?:public|private|protected)\s+' + re.escape(path.stem) + r'\s*\([^)]*\)\s*\{', body):
        depth, i = 0, ctor.end() - 1
        while i < len(body):
            if body[i] == '{':
                depth += 1
            elif body[i] == '}':
                depth -= 1
                if depth == 0:
                    assigned_in_constructor |= set(re.findall(r'this\.(\w+)\s*=', body[ctor.end():i]))
                    break
            i += 1
    for match in re.finditer(r'(?:^|\n)[ \t]*(?:public|private|protected|static|final|volatile|transient)[^\n;={}()]*?[ \t](\w+)[ \t]*=([^;\n]*);', body):
        if depths[match.start()] != 1:
            continue
        name, init, position = match.group(1), match.group(2), len(declared_order)
        # Anonymous-class bodies are methods, where reading a constructor final is legal, so the
        # initializer is cut at the first `){`. Lambda initializers (the (c)/(d) bug class) keep
        # their body because `()->{...}` does not contain `){`.
        direct = init.split('){')[0]
        for ref in re.findall(r'(?<![.\w])(\w+)\b(?!\s*=(?!=))', direct):
            if ref == name or ref in {'this', 'true', 'false', 'null'}:
                continue
            if ref in declared_order and declared_order[ref] > position:
                field_forward_hits.append((path.name, name, ref, 'forward'))
            elif ref in final_fields and ref in assigned_in_constructor:
                field_forward_hits.append((path.name, name, ref, 'constructor-final'))
checks.append(check("no duplicate fields and no field initializer reads a later or constructor-assigned final field",
    not field_forward_hits and not duplicate_field_hits))

# 19. Signature coherence. This is the class of the four delivery bugs that were already fixed in
#     the bundle before upload: a call with the wrong arity (a), and a field whose declaration order
#     or duplication broke the initializer (b/c/d). Both bare same-file calls and calls through a
#     known first-party receiver are checked against declared arities (varargs excluded).
def blank_comments(text: str) -> str:
    """Replace comments with spaces so string literals keep their original offsets."""
    out, i, state = [], 0, "code"
    while i < len(text):
        c, n = text[i], text[i + 1] if i + 1 < len(text) else ""
        if state == "code":
            if c == "/" and n == "/":
                state, out = "line", out + ["  "]
                i += 2
                continue
            if c == "/" and n == "*":
                state, out = "block", out + ["  "]
                i += 2
                continue
            out.append(c)
        elif state == "line":
            if c == "\n":
                state = "code"
                out.append(c)
            else:
                out.append(" ")
        else:
            if c == "*" and n == "/":
                state, out = "code", out + ["  "]
                i += 2
                continue
            out.append("\n" if c == "\n" else " ")
        i += 1
    return "".join(out)

def count_args(text: str, open_paren: int) -> int:
    """Arity of the call whose '(' is at open_paren, ignoring strings, chars and nested groups."""
    depth, commas, i, state = 0, 0, open_paren, "code"
    while i < len(text):
        c, n = text[i], text[i + 1] if i + 1 < len(text) else ""
        if state == "code":
            if c == '"' or c == "'":
                state = "string" if c == '"' else "char"
            elif c == "/" and n == "/":
                state = "line"
            elif c in "([{":
                depth += 1
            elif c in ")]}":
                depth -= 1
                if depth == 0:
                    return 0 if text[open_paren + 1:i].strip() == "" else commas + 1
            elif c == "," and depth == 1:
                commas += 1
        elif state in ("string", "char"):
            if c == "\\":
                i += 1
            elif (state == "string" and c == '"') or (state == "char" and c == "'"):
                state = "code"
        elif state == "line" and c == "\n":
            state = "code"
        i += 1
    return -1

declared_methods, varargs_methods = {}, set()
for path, text in sources.items():
    cleaned = blank_comments(text)
    for match in re.finditer(r'(?:public|private|protected)[\w\s<>\[\],.?@]*?\b(\w+)\s*\(([^)]*)\)\s*(?:throws[^{;]*)?[{;]', cleaned):
        name, params = match.group(1), match.group(2)
        declared_methods.setdefault(name, set()).add(0 if not params.strip() else len([p for p in params.split(',') if p.strip()]))
        if '...' in params:
            varargs_methods.add(name)

receiver_types = {'WindowController', 'SnapController', 'LauncherPrefs', 'RootBridge', 'DockedPairManager',
                  'ChromeManager', 'TaskbarOverlay', 'TaskViewOverlay', 'ActionCenterOverlay', 'ResizeGripManager'}
receiver_names = {name[0].lower() + name[1:]: name for name in receiver_types} | {'bridge': 'RootBridge', 'root': 'RootBridge'}
call_arity_hits = []
for path, text in sources.items():
    cleaned = blank_comments(text)
    own = {}
    for match in re.finditer(r'(?:public|private|protected)[\w\s<>\[\],.?@]*?\b(\w+)\s*\(([^)]*)\)\s*(?:throws[^{;]*)?[{;]', cleaned):
        params = match.group(2)
        own.setdefault(match.group(1), set()).add(0 if not params.strip() else len([p for p in params.split(',') if p.strip()]))
    for match in re.finditer(r'(?<![.\w])([a-zA-Z_]\w*)\s*\(', cleaned):
        name = match.group(1)
        if name in ('if', 'for', 'while', 'switch', 'catch', 'return', 'new', 'super', 'this', 'synchronized'):
            continue
        if name in own and name not in varargs_methods:
            arity = count_args(cleaned, match.end() - 1)
            if arity not in own[name]:
                call_arity_hits.append((path.name, name, arity, sorted(own[name]), 'same-file'))
    for match in re.finditer(r'\b([a-z]\w*)\.(\w+)\s*\(', cleaned):
        receiver, name = match.group(1), match.group(2)
        if receiver not in receiver_names or name not in declared_methods or name in varargs_methods:
            continue
        arity = count_args(cleaned, match.end() - 1)
        if arity not in declared_methods[name]:
            call_arity_hits.append((path.name, f'{receiver}.{name}', arity, sorted(declared_methods[name]), receiver_names[receiver]))
# Constructors of first-party classes follow the same rule (a stale `new X(a, b)` after a signature
# change is exactly how the delivery bugs started).
ctor_arities = {}
for path, text in sources.items():
    cleaned = blank_comments(text)
    for match in re.finditer(r'\b(?:public|private|protected)\s+(\w+)\s*\(([^)]*)\)\s*(?:throws[^{;]*)?\{', cleaned):
        if match.group(1) != path.stem:
            continue
        params = match.group(2)
        ctor_arities.setdefault(match.group(1), set()).add(0 if not params.strip() else len([p for p in params.split(',') if p.strip()]))
ctor_hits = []
for path, text in sources.items():
    cleaned = blank_comments(text)
    for match in re.finditer(r'\bnew\s+([A-Z]\w*)\s*\(', cleaned):
        name = match.group(1)
        if name not in ctor_arities or name in varargs_methods:
            continue
        arity = count_args(cleaned, match.end() - 1)
        if arity not in ctor_arities[name]:
            ctor_hits.append((path.name, name, arity, sorted(ctor_arities[name])))
checks.append(check("constructor invocations match declared constructor arity for first-party classes",
    not ctor_hits))
checks.append(check("call arity matches declared method arity for same-file calls and first-party receivers",
    not call_arity_hits))

# 20. The root bridge must authenticate in both directions with a token-bound, nonce-fresh proof.
root_bridge = read("app/src/main/java/ru/winlauncher/bridge/RootBridge.java")
root_server = read("app/src/main/java/ru/winlauncher/root/RootServer.java")
checks.append(check("root bridge performs mutual token authentication with a fresh nonce",
    all(x in root_bridge for x in ['newNonce()', 'handshakeProof(token, nonce)', 'optString("proof"'])
    and re.search(r'handshakeProof\(authToken,\s*nonce\)', root_server) is not None
    and 'put("proof"' in root_server and 'nonce.length() < 16' in root_server
    and re.search(r'String nonce\s*=\s*newNonce\(\)', root_bridge) is not None
    and 'setSoTimeout(IO_TIMEOUT_MS)' in root_bridge))

if not all(checks):
    sys.exit(1)
print(f"{len(checks)}/{len(checks)} static source-coherence checks passed; not a Java build, APK test, or device/runtime acceptance.")
